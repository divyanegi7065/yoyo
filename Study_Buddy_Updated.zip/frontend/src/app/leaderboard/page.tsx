"use client";

import React, { useState, useEffect } from "react";
import AppShell from "@/components/AppShell";
import {
  fetchGlobalLeaderboard,
  getStoredUserId,
  GlobalLeaderboardData,
  GlobalLeaderboardEntry,
  GlobalUserStanding,
} from "@/lib/api";
import {
  Trophy,
  Flame,
  Award,
  Sparkles,
  Search,
  CheckCircle2,
  TrendingUp,
  Shield,
  Clock,
  ArrowUp,
  Crown,
  Medal,
} from "lucide-react";

export default function LeaderboardPage() {
  const [data, setData] = useState<GlobalLeaderboardData | null>(null);
  const [metric, setMetric] = useState<"xp" | "tasks" | "streak">("xp");
  const [timeframe, setTimeframe] = useState<"all" | "weekly" | "daily">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  const loadLeaderboard = async () => {
    const userId = getStoredUserId();
    try {
      setLoading(true);
      const res = await fetchGlobalLeaderboard(metric, timeframe, userId || undefined);
      setData(res);
    } catch (err) {
      console.error("Leaderboard load error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLeaderboard();
  }, [metric, timeframe]);

  const podium = data?.podium || [];
  const leaderboard = data?.leaderboard || [];
  const userStanding: GlobalUserStanding | null = data?.user_standing || null;

  const filteredEntries = leaderboard.filter(
    (entry) =>
      entry.student_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.grade_stream.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getRankBadge = (rank: number) => {
    if (rank === 1) return <span className="text-xl">🥇</span>;
    if (rank === 2) return <span className="text-xl">🥈</span>;
    if (rank === 3) return <span className="text-xl">🥉</span>;
    return <span className="font-mono font-bold text-gray-400">#{rank}</span>;
  };

  return (
    <AppShell>
      <div className="space-y-8 animate-fade-in">
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>Worldwide Academic Rankings</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white mt-1">
              Global Leaderboard & Standings
            </h1>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1 max-w-2xl">
              Compare your academic sprints, earned XP, and active streaks against learners across Class 6 to 3rd-Year UG worldwide.
            </p>
          </div>

          {/* Metric Selector Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex bg-gray-100 dark:bg-[#13232C] p-1 rounded-2xl border border-gray-200 dark:border-[#1E333D]">
              <button
                onClick={() => setMetric("xp")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  metric === "xp"
                    ? "bg-teal-600 text-white shadow-sm"
                    : "text-gray-600 dark:text-gray-300 hover:text-white"
                }`}
              >
                Total XP
              </button>
              <button
                onClick={() => setMetric("tasks")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  metric === "tasks"
                    ? "bg-teal-600 text-white shadow-sm"
                    : "text-gray-600 dark:text-gray-300 hover:text-white"
                }`}
              >
                Tasks Done
              </button>
              <button
                onClick={() => setMetric("streak")}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  metric === "streak"
                    ? "bg-teal-600 text-white shadow-sm"
                    : "text-gray-600 dark:text-gray-300 hover:text-white"
                }`}
              >
                Active Streaks
              </button>
            </div>

            {/* Timeframe Toggle */}
            <div className="flex bg-gray-100 dark:bg-[#13232C] p-1 rounded-2xl border border-gray-200 dark:border-[#1E333D]">
              {(["all", "weekly", "daily"] as const).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold capitalize transition-all ${
                    timeframe === tf
                      ? "bg-salmon-500 text-white shadow-sm"
                      : "text-gray-500 hover:text-gray-800 dark:hover:text-white"
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* FEATURE 4 HIGHLIGHT: User's Global Standing Banner */}
        {userStanding && (
          <div className="p-6 rounded-3xl bg-gradient-to-r from-teal-800 via-teal-700 to-[#0A2F35] text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-salmon-500 to-amber-400 flex flex-col items-center justify-center font-black shadow-lg shadow-salmon-500/40 border-2 border-white/20">
                <span className="text-xl">#{userStanding.rank}</span>
                <span className="text-[9px] uppercase tracking-wider text-white/90">Global</span>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-salmon-500/20 text-salmon-400 border border-salmon-400/30">
                    Top {userStanding.percentile}% Worldwide
                  </span>
                  <span className="text-xs text-teal-200 font-mono">
                    Tier: {userStanding.tier}
                  </span>
                </div>
                <h3 className="text-lg font-extrabold text-white mt-0.5">
                  Your Current Global Standing
                </h3>
                <p className="text-xs text-teal-100">
                  Ranked #{userStanding.rank} out of {userStanding.total_participants} scholars globally.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className="text-xs text-teal-200 uppercase font-semibold">Total XP</div>
                <div className="text-xl font-mono font-extrabold text-white">
                  {userStanding.total_xp}
                </div>
              </div>

              <div className="text-center">
                <div className="text-xs text-teal-200 uppercase font-semibold">Streak</div>
                <div className="text-xl font-mono font-extrabold text-salmon-400 flex items-center justify-center gap-1">
                  <Flame className="w-4 h-4 fill-salmon-400" />
                  {userStanding.streak_days}d
                </div>
              </div>

              {userStanding.xp_to_next_rank > 0 && userStanding.next_scholar_name && (
                <div className="text-right hidden sm:block">
                  <div className="text-[10px] text-teal-200 uppercase font-bold flex items-center justify-end gap-1">
                    <ArrowUp className="w-3 h-3 text-salmon-400" />
                    <span>Next Rank</span>
                  </div>
                  <div className="text-xs font-semibold text-white">
                    +{userStanding.xp_to_next_rank} XP to pass {userStanding.next_scholar_name.split(" ")[0]}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Podium Display (Top 3 Scholars) */}
        {podium.length >= 3 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end pt-4">
            {/* 2nd Place (Silver) */}
            <div className="order-2 md:order-1 p-6 rounded-3xl bg-white dark:bg-[#0F172A] border-2 border-slate-300 dark:border-slate-700 shadow-lg text-center space-y-3 transform md:-translate-y-2">
              <div className="w-16 h-16 rounded-full mx-auto bg-slate-100 dark:bg-slate-800 border-4 border-slate-300 dark:border-slate-600 flex items-center justify-center text-3xl shadow-md">
                🥈
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  2nd Place
                </span>
                <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
                  {podium[1]?.student_name}
                </h3>
                <p className="text-xs text-gray-500 truncate">{podium[1]?.grade_stream}</p>
              </div>

              <div className="pt-2 border-t border-gray-100 dark:border-[#1E333D] flex justify-around text-xs">
                <div>
                  <div className="font-extrabold text-teal-600 dark:text-teal-400 font-mono">
                    {podium[1]?.total_xp}
                  </div>
                  <div className="text-[10px] text-gray-400">XP</div>
                </div>
                <div>
                  <div className="font-extrabold text-salmon-500 font-mono">
                    {podium[1]?.streak_days}d
                  </div>
                  <div className="text-[10px] text-gray-400">Streak</div>
                </div>
                <div>
                  <div className="font-extrabold text-gray-800 dark:text-gray-200 font-mono">
                    {podium[1]?.tasks_completed}
                  </div>
                  <div className="text-[10px] text-gray-400">Tasks</div>
                </div>
              </div>
            </div>

            {/* 1st Place (Gold Crown) */}
            <div className="order-1 md:order-2 p-7 rounded-3xl bg-gradient-to-b from-amber-500/10 via-white to-white dark:from-amber-500/15 dark:via-[#0F172A] dark:to-[#0F172A] border-2 border-amber-400 dark:border-amber-500/60 shadow-xl text-center space-y-3 transform md:-translate-y-6 relative overflow-hidden">
              <div className="absolute top-2 right-2 text-amber-500">
                <Crown className="w-6 h-6 animate-bounce-gentle" />
              </div>
              <div className="w-20 h-20 rounded-full mx-auto bg-gradient-to-tr from-amber-400 to-yellow-300 border-4 border-amber-200 dark:border-amber-500 flex items-center justify-center text-4xl shadow-xl shadow-amber-500/30">
                🥇
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-500">
                  Global Champion
                </span>
                <h3 className="text-lg font-black text-gray-900 dark:text-white">
                  {podium[0]?.student_name}
                </h3>
                <p className="text-xs text-gray-500 truncate">{podium[0]?.grade_stream}</p>
              </div>

              <div className="pt-3 border-t border-amber-200/60 dark:border-amber-500/30 flex justify-around text-xs">
                <div>
                  <div className="text-sm font-black text-teal-600 dark:text-teal-400 font-mono">
                    {podium[0]?.total_xp}
                  </div>
                  <div className="text-[10px] text-gray-400 uppercase font-bold">XP</div>
                </div>
                <div>
                  <div className="text-sm font-black text-salmon-500 font-mono">
                    {podium[0]?.streak_days}d
                  </div>
                  <div className="text-[10px] text-gray-400 uppercase font-bold">Streak</div>
                </div>
                <div>
                  <div className="text-sm font-black text-gray-800 dark:text-gray-200 font-mono">
                    {podium[0]?.tasks_completed}
                  </div>
                  <div className="text-[10px] text-gray-400 uppercase font-bold">Tasks</div>
                </div>
              </div>
            </div>

            {/* 3rd Place (Bronze) */}
            <div className="order-3 p-6 rounded-3xl bg-white dark:bg-[#0F172A] border-2 border-amber-700/30 dark:border-amber-800/60 shadow-lg text-center space-y-3 transform md:-translate-y-1">
              <div className="w-16 h-16 rounded-full mx-auto bg-amber-100 dark:bg-amber-950/60 border-4 border-amber-700/40 flex items-center justify-center text-3xl shadow-md">
                🥉
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                  3rd Place
                </span>
                <h3 className="text-base font-extrabold text-gray-900 dark:text-white">
                  {podium[2]?.student_name}
                </h3>
                <p className="text-xs text-gray-500 truncate">{podium[2]?.grade_stream}</p>
              </div>

              <div className="pt-2 border-t border-gray-100 dark:border-[#1E333D] flex justify-around text-xs">
                <div>
                  <div className="font-extrabold text-teal-600 dark:text-teal-400 font-mono">
                    {podium[2]?.total_xp}
                  </div>
                  <div className="text-[10px] text-gray-400">XP</div>
                </div>
                <div>
                  <div className="font-extrabold text-salmon-500 font-mono">
                    {podium[2]?.streak_days}d
                  </div>
                  <div className="text-[10px] text-gray-400">Streak</div>
                </div>
                <div>
                  <div className="font-extrabold text-gray-800 dark:text-gray-200 font-mono">
                    {podium[2]?.tasks_completed}
                  </div>
                  <div className="text-[10px] text-gray-400">Tasks</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Global Standings Table */}
        <div className="p-6 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-gray-100 dark:border-[#1E333D] gap-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-gray-300">
              Complete Worldwide Standings Roster
            </h2>

            {/* Search Input */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search scholars or streams..."
                className="w-full pl-9 pr-3 py-1.5 rounded-xl text-xs bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-gray-900 dark:text-white"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-gray-200 dark:border-[#1E333D] text-gray-400 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-3">Rank</th>
                  <th className="py-3 px-3">Scholar</th>
                  <th className="py-3 px-3">Academic Stream</th>
                  <th className="py-3 px-3">Tier</th>
                  <th className="py-3 px-3 text-center">Streak</th>
                  <th className="py-3 px-3 text-right">Tasks</th>
                  <th className="py-3 px-3 text-right">Total XP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-[#1E333D]/60">
                {filteredEntries.map((entry) => {
                  const isYou = entry.is_current_user;
                  return (
                    <tr
                      key={entry.student_id}
                      className={`transition-colors ${
                        isYou
                          ? "bg-teal-500/10 dark:bg-teal-500/15 font-bold border-l-4 border-teal-500"
                          : "hover:bg-gray-50 dark:hover:bg-[#13232C]/60"
                      }`}
                    >
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        {getRankBadge(entry.rank)}
                      </td>
                      <td className="py-3.5 px-3">
                        <div className="flex items-center space-x-2.5">
                          <span className="text-base">{entry.avatar}</span>
                          <div>
                            <div className="font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                              <span>{entry.student_name}</span>
                              {isYou && (
                                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-salmon-500 text-white font-bold">
                                  YOU
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-gray-400">Level {entry.level}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-3 text-gray-600 dark:text-gray-300 whitespace-nowrap">
                        {entry.grade_stream}
                      </td>
                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 font-semibold border border-teal-500/20">
                          {entry.tier}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-center whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 font-mono text-salmon-500 font-bold">
                          <Flame className="w-3.5 h-3.5 fill-salmon-500" />
                          {entry.streak_days}d
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono font-bold text-gray-700 dark:text-gray-300 whitespace-nowrap">
                        {entry.tasks_completed}
                      </td>
                      <td className="py-3.5 px-3 text-right font-mono font-extrabold text-teal-600 dark:text-teal-400 whitespace-nowrap">
                        {entry.total_xp} XP
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

