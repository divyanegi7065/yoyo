"use client";

import React, { useState, useEffect } from "react";
import AppShell from "@/components/AppShell";
import {
  fetchSquads,
  createSquad,
  joinSquad,
  fetchSquadFeed,
  postToSquadFeed,
  reactToFeedItem,
  getStoredUserId,
  getStoredProfile,
  StudySquad,
  SquadFeedItem,
  SquadFeedResponse,
} from "@/lib/api";
import {
  Users,
  UserPlus,
  PlusCircle,
  Sparkles,
  Flame,
  Award,
  Send,
  MessageSquare,
  Shield,
  Lock,
  Globe,
  CheckCircle2,
  Trophy,
  Heart,
  Lightbulb,
  Rocket,
  Search,
} from "lucide-react";

export default function SquadsPage() {
  const [squads, setSquads] = useState<StudySquad[]>([]);
  const [activeSquad, setActiveSquad] = useState<StudySquad | null>(null);
  const [feed, setFeed] = useState<SquadFeedItem[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"feed" | "explore" | "create">("feed");

  // Create form state
  const [newSquadName, setNewSquadName] = useState("");
  const [newSquadDesc, setNewSquadDesc] = useState("");
  const [newSquadSubject, setNewSquadSubject] = useState("Programming");
  const [isPrivate, setIsPrivate] = useState(false);
  const [creating, setCreating] = useState(false);

  // Join by code state
  const [joinCodeInput, setJoinCodeInput] = useState("");
  const [joining, setJoining] = useState(false);

  // Post broadcast state
  const [broadcastText, setBroadcastText] = useState("");
  const [posting, setPosting] = useState(false);

  // Status message
  const [message, setMessage] = useState<string | null>(null);

  const loadSquads = async () => {
    const userId = getStoredUserId();
    try {
      setLoading(true);
      const res = await fetchSquads(userId || undefined);
      setSquads(res.squads);

      // Set active squad to user's first joined squad or the first public squad
      if (res.squads.length > 0) {
        const mySquad = res.squads.find((s) => s.is_member) || res.squads[0];
        setActiveSquad(mySquad);
        await loadSquadDetails(mySquad.id);
      }
    } catch (err) {
      console.error("Squads load error:", err);
    } finally {
      setLoading(false);
    }
  };

  const loadSquadDetails = async (squadId: number) => {
    try {
      const res: SquadFeedResponse = await fetchSquadFeed(squadId);
      setFeed(res.feed);
      setMembers(res.squad.members || []);
    } catch (err) {
      console.error("Failed to load squad feed:", err);
    }
  };

  useEffect(() => {
    loadSquads();
  }, []);

  const handleSelectSquad = async (squad: StudySquad) => {
    setActiveSquad(squad);
    setActiveTab("feed");
    await loadSquadDetails(squad.id);
  };

  const handleCreateSquad = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSquadName.trim()) return;

    setCreating(true);
    setMessage(null);
    try {
      const userId = getStoredUserId() || "student-temp";
      const profile = getStoredProfile();
      const res = await createSquad({
        name: newSquadName.trim(),
        description: newSquadDesc.trim(),
        focus_subject: newSquadSubject,
        is_private: isPrivate,
        creator_id: userId,
        creator_name: profile?.full_name || "Scholar",
      });

      setMessage(res.message);
      setNewSquadName("");
      setNewSquadDesc("");
      await loadSquads();
      setActiveTab("feed");
    } catch (err: any) {
      console.error("Create squad error:", err);
      setMessage(err.message || "Failed to create study squad.");
    } finally {
      setCreating(false);
      setTimeout(() => setMessage(null), 5000);
    }
  };

  const handleJoinByCode = async (codeToJoin?: string) => {
    const code = (codeToJoin || joinCodeInput).trim().toUpperCase();
    if (!code) return;

    setJoining(true);
    setMessage(null);
    try {
      const userId = getStoredUserId() || "student-temp";
      const profile = getStoredProfile();
      const res = await joinSquad(code, profile?.full_name || "Scholar", userId);
      setMessage(res.message);
      setJoinCodeInput("");
      await loadSquads();
      if (res.squad_id) {
        const joined = squads.find((s) => s.id === res.squad_id);
        if (joined) handleSelectSquad(joined);
      }
    } catch (err: any) {
      console.error("Join squad error:", err);
      setMessage(err.message || "Failed to join squad with code.");
    } finally {
      setJoining(false);
      setTimeout(() => setMessage(null), 5000);
    }
  };

  const handlePostBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSquad || !broadcastText.trim()) return;

    setPosting(true);
    try {
      const userId = getStoredUserId() || "student-temp";
      const profile = getStoredProfile();
      await postToSquadFeed(activeSquad.id, {
        student_id: userId,
        student_name: profile?.full_name || "Scholar",
        content: broadcastText.trim(),
        activity_type: "message",
      });
      setBroadcastText("");
      await loadSquadDetails(activeSquad.id);
    } catch (err) {
      console.error("Post broadcast error:", err);
    } finally {
      setPosting(false);
    }
  };

  const handleReaction = async (itemId: number, reactionType: string) => {
    const userId = getStoredUserId() || "student-temp";
    // Optimistic UI reaction update
    setFeed((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const userList = item.reacted_users?.[reactionType] || [];
          const hasReacted = userList.includes(userId);
          const currentCount = item.reactions?.[reactionType] || 0;
          return {
            ...item,
            reactions: {
              ...item.reactions,
              [reactionType]: hasReacted ? Math.max(0, currentCount - 1) : currentCount + 1,
            },
            reacted_users: {
              ...item.reacted_users,
              [reactionType]: hasReacted
                ? userList.filter((u) => u !== userId)
                : [...userList, userId],
            },
          };
        }
        return item;
      })
    );

    try {
      await reactToFeedItem(itemId, reactionType, userId);
    } catch (err) {
      console.error("Failed to react to item", err);
      if (activeSquad) await loadSquadDetails(activeSquad.id);
    }
  };

  const mySquads = squads.filter((s) => s.is_member);
  const publicSquads = squads.filter((s) => !s.is_private);

  return (
    <AppShell>
      <div className="space-y-8 animate-fade-in">
        {/* Header Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
              <Users className="w-4 h-4 text-salmon-500" />
              <span>Social Study Groups & Squad Sharing</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white mt-1">
              Study Squads & Achievement Channel
            </h1>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1 max-w-2xl">
              Team up with peers, broadcast daily milestones, celebrate level-ups, and keep each other accountable with interactive reactions.
            </p>
          </div>

          {/* Navigation Pills */}
          <div className="flex bg-gray-100 dark:bg-[#13232C] p-1 rounded-2xl border border-gray-200 dark:border-[#1E333D]">
            <button
              onClick={() => setActiveTab("feed")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === "feed"
                  ? "bg-teal-600 text-white shadow-sm"
                  : "text-gray-600 dark:text-gray-300 hover:text-white"
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Squad Feed</span>
            </button>
            <button
              onClick={() => setActiveTab("explore")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === "explore"
                  ? "bg-teal-600 text-white shadow-sm"
                  : "text-gray-600 dark:text-gray-300 hover:text-white"
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>Explore Squads</span>
            </button>
            <button
              onClick={() => setActiveTab("create")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === "create"
                  ? "bg-salmon-500 text-white shadow-sm"
                  : "text-gray-600 dark:text-gray-300 hover:text-white"
              }`}
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>Create Squad</span>
            </button>
          </div>
        </div>

        {/* Status Message */}
        {message && (
          <div className="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/30 text-teal-600 dark:text-teal-400 text-sm font-semibold flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-salmon-500 flex-shrink-0" />
              <span>{message}</span>
            </div>
            <button onClick={() => setMessage(null)} className="text-xs text-gray-400 hover:text-gray-600">
              Dismiss
            </button>
          </div>
        )}

        {/* TAB 1: SQUAD FEED VIEW */}
        {activeTab === "feed" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column (8 Columns): Active Squad Feed */}
            <div className="lg:col-span-8 space-y-6">
              {/* Active Squad Header Bar */}
              {activeSquad ? (
                <div className="p-6 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-salmon-500/10 text-salmon-500 border border-salmon-500/20 uppercase tracking-wider font-mono">
                        {activeSquad.code}
                      </span>
                      <span className="text-xs text-teal-600 dark:text-teal-400 font-semibold">
                        • {activeSquad.focus_subject} Track
                      </span>
                    </div>
                    <h2 className="text-xl font-extrabold text-gray-900 dark:text-white mt-1">
                      {activeSquad.name}
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                      {activeSquad.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-xs font-bold text-gray-900 dark:text-white">
                        {members.length} Members
                      </div>
                      <div className="text-[11px] text-teal-600 dark:text-teal-400">
                        Active Channel
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(activeSquad.code);
                        setMessage(`Squad Invite Code "${activeSquad.code}" copied to clipboard! Share with friends.`);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#13232C] hover:bg-gray-200 dark:hover:bg-[#1E333D] text-xs font-bold text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-[#1E333D] transition-all"
                    >
                      Copy Code
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D]">
                  <p className="text-sm font-semibold text-gray-500">No squad selected.</p>
                </div>
              )}

              {/* Broadcast Post Input Form */}
              {activeSquad && (
                <form
                  onSubmit={handlePostBroadcast}
                  className="p-4 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm space-y-3"
                >
                  <div className="flex items-center space-x-2 text-xs font-bold text-gray-500">
                    <Sparkles className="w-3.5 h-3.5 text-salmon-500" />
                    <span>Broadcast a Study Milestone or Encouragement</span>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={broadcastText}
                      onChange={(e) => setBroadcastText(e.target.value)}
                      placeholder="Share completed sprints, study streaks, or cheer your peers on..."
                      className="flex-1 px-4 py-2.5 rounded-2xl bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-xs text-gray-900 dark:text-white focus:ring-1 focus:ring-teal-500 font-medium"
                    />
                    <button
                      type="submit"
                      disabled={posting || !broadcastText.trim()}
                      className="px-5 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-md shadow-teal-600/30 transition-all disabled:opacity-50 flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Post</span>
                    </button>
                  </div>
                </form>
              )}

              {/* Squad Feed Channel Items */}
              <div className="space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-gray-400 px-1 flex items-center justify-between">
                  <span>Activity Channel Feed</span>
                  <span>{feed.length} Broadcasts</span>
                </div>

                {feed.length === 0 ? (
                  <div className="p-8 text-center text-xs text-gray-400 border border-dashed border-gray-200 dark:border-[#1E333D] rounded-3xl">
                    No broadcasts in this squad yet. Be the first to share an achievement!
                  </div>
                ) : (
                  feed.map((item) => {
                    const isMilestone = item.activity_type === "level_up" || item.activity_type === "badge_earned" || item.activity_type === "milestone";
                    const userId = getStoredUserId() || "student-temp";

                    return (
                      <div
                        key={item.id}
                        className={`p-5 rounded-3xl border transition-all ${
                          isMilestone
                            ? "bg-gradient-to-r from-teal-50/60 to-white dark:from-[#0B2127]/50 dark:to-[#0F172A] border-teal-500/40 shadow-sm"
                            : "bg-white dark:bg-[#0F172A] border-gray-200 dark:border-[#1E333D]"
                        }`}
                      >
                        {/* Member author and timestamp */}
                        <div className="flex items-center justify-between mb-2.5">
                          <div className="flex items-center space-x-2.5">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-teal-600 to-teal-400 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                              {item.student_name ? item.student_name[0] : "S"}
                            </div>
                            <div>
                              <div className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                                <span>{item.student_name}</span>
                                {item.badge_name && (
                                  <span className="text-[10px] px-2 py-0.2 rounded-full bg-salmon-500/10 text-salmon-500 border border-salmon-500/30 font-bold">
                                    {item.badge_name}
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-gray-400 font-mono">
                                {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>

                          <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">
                            {item.activity_type.replace("_", " ")}
                          </span>
                        </div>

                        {/* Content text */}
                        <p className="text-xs sm:text-sm text-gray-800 dark:text-gray-200 font-medium leading-relaxed mb-4 pl-1">
                          {item.content}
                        </p>

                        {/* Interactive Encouragement Reaction Bar */}
                        <div className="flex items-center gap-1.5 pt-2 border-t border-gray-100 dark:border-[#1E333D]/60">
                          {[
                            { type: "fire", emoji: "🔥", label: "Fire" },
                            { type: "clap", emoji: "👏", label: "Clap" },
                            { type: "rocket", emoji: "🚀", label: "Rocket" },
                            { type: "brain", emoji: "💡", label: "Brain" },
                            { type: "heart", emoji: "❤️", label: "Heart" },
                          ].map((rx) => {
                            const count = item.reactions?.[rx.type] || 0;
                            const hasReacted = item.reacted_users?.[rx.type]?.includes(userId);

                            return (
                              <button
                                key={rx.type}
                                onClick={() => handleReaction(item.id, rx.type)}
                                className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                                  hasReacted
                                    ? "bg-salmon-500/20 text-salmon-500 border border-salmon-500/40 shadow-xs"
                                    : "bg-gray-100 dark:bg-[#13232C] text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-[#1E333D] border border-transparent"
                                }`}
                              >
                                <span>{rx.emoji}</span>
                                {count > 0 && <span className="font-mono text-[11px]">{count}</span>}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Right Column (4 Columns): Squad Switcher & Member Roster */}
            <div className="lg:col-span-4 space-y-6">
              {/* Join By Code Quick Box */}
              <div className="p-5 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                  <UserPlus className="w-3.5 h-3.5 text-salmon-500" />
                  <span>Join Squad by Code</span>
                </h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={joinCodeInput}
                    onChange={(e) => setJoinCodeInput(e.target.value)}
                    placeholder="e.g. NEET-26 or SQD-1234"
                    className="flex-1 px-3 py-2 rounded-xl text-xs bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-gray-900 dark:text-white uppercase font-mono"
                  />
                  <button
                    onClick={() => handleJoinByCode()}
                    disabled={joining || !joinCodeInput.trim()}
                    className="px-3.5 py-2 rounded-xl bg-salmon-500 hover:bg-salmon-600 text-white font-bold text-xs transition-all disabled:opacity-50"
                  >
                    Join
                  </button>
                </div>
              </div>

              {/* Enrolled Squads List */}
              <div className="p-5 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-[#1E333D]">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-gray-300">
                    Your Enrolled Squads ({mySquads.length})
                  </h3>
                  <button
                    onClick={() => setActiveTab("explore")}
                    className="text-[11px] text-teal-600 dark:text-teal-400 hover:underline font-bold"
                  >
                    Browse More
                  </button>
                </div>

                <div className="space-y-2">
                  {squads.map((sq) => {
                    const isSelected = activeSquad?.id === sq.id;
                    return (
                      <div
                        key={sq.id}
                        onClick={() => handleSelectSquad(sq)}
                        className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? "bg-teal-500/10 border-teal-500/40 text-teal-700 dark:text-teal-300 shadow-xs"
                            : "bg-gray-50 dark:bg-[#13232C]/60 border-gray-200 dark:border-[#1E333D] hover:border-teal-500/40"
                        }`}
                      >
                        <div>
                          <div className="text-xs font-bold text-gray-900 dark:text-white truncate max-w-[160px]">
                            {sq.name}
                          </div>
                          <div className="text-[10px] text-gray-400 font-mono">
                            Code: {sq.code} • {sq.member_count} members
                          </div>
                        </div>

                        {sq.is_member && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 font-bold">
                            Joined
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Squad Leaderboard / Member Roster */}
              <div className="p-5 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-[#1E333D]">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5 text-salmon-500" />
                    <span>Squad Member Standings</span>
                  </h3>
                  <span className="text-[11px] text-gray-400 font-mono">{members.length} members</span>
                </div>

                <div className="space-y-2">
                  {members.map((m, idx) => (
                    <div
                      key={m.student_id}
                      className="p-2.5 rounded-xl bg-gray-50 dark:bg-[#13232C]/60 border border-gray-100 dark:border-[#1E333D] flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center space-x-2">
                        <span className="font-mono font-bold text-gray-400 text-[11px]">
                          #{idx + 1}
                        </span>
                        <div>
                          <div className="font-bold text-gray-900 dark:text-white flex items-center gap-1">
                            <span>{m.student_name}</span>
                            {m.role === "admin" && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-500 font-bold uppercase">
                                Leader
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <span className="font-mono font-bold text-teal-600 dark:text-teal-400">
                        {m.xp_contributed} XP
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: EXPLORE PUBLIC SQUADS */}
        {activeTab === "explore" && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-gray-200 dark:border-[#1E333D] gap-4">
              <div>
                <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                  Discover Public Study Squads
                </h2>
                <p className="text-xs text-gray-500">
                  Find squads aligned with your specific academic goals and syllabus tracks
                </p>
              </div>

              {/* Join code quick bar */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={joinCodeInput}
                  onChange={(e) => setJoinCodeInput(e.target.value)}
                  placeholder="Enter Squad Code..."
                  className="px-3.5 py-2 rounded-xl text-xs bg-gray-100 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-gray-900 dark:text-white uppercase font-mono"
                />
                <button
                  onClick={() => handleJoinByCode()}
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs"
                >
                  Join Code
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {publicSquads.map((sq) => (
                <div
                  key={sq.id}
                  className="p-6 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm flex flex-col justify-between space-y-4 hover:border-teal-500 transition-all group"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 font-bold border border-teal-500/20">
                        {sq.focus_subject}
                      </span>
                      <span className="text-xs text-gray-400 font-mono">Code: {sq.code}</span>
                    </div>

                    <h3 className="text-base font-bold text-gray-900 dark:text-white group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                      {sq.name}
                    </h3>

                    <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">
                      {sq.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-gray-100 dark:border-[#1E333D] flex items-center justify-between">
                    <div className="text-xs text-gray-400">
                      <span className="font-bold text-gray-800 dark:text-gray-200">
                        {sq.member_count}
                      </span>{" "}
                      Members
                    </div>

                    {sq.is_member ? (
                      <button
                        onClick={() => handleSelectSquad(sq)}
                        className="px-4 py-2 rounded-xl bg-teal-50 dark:bg-teal-500/10 text-teal-600 dark:text-teal-400 font-bold text-xs hover:bg-teal-100"
                      >
                        Open Feed
                      </button>
                    ) : (
                      <button
                        onClick={() => handleJoinByCode(sq.code)}
                        className="px-4 py-2 rounded-xl bg-salmon-500 hover:bg-salmon-600 text-white font-bold text-xs shadow-md shadow-salmon-500/30 transition-all flex items-center gap-1"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Join Squad</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: CREATE SQUAD VIEW */}
        {activeTab === "create" && (
          <div className="max-w-2xl mx-auto p-8 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm space-y-6">
            <div className="pb-4 border-b border-gray-200 dark:border-[#1E333D]">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-salmon-500" />
                <span>Create a New Study Squad</span>
              </h2>
              <p className="text-xs text-gray-500 mt-1">
                Form a private or public squad with peers. An automatic 6-character room code will be generated for invitations.
              </p>
            </div>

            <form onSubmit={handleCreateSquad} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
                  Squad Name:
                </label>
                <input
                  type="text"
                  value={newSquadName}
                  onChange={(e) => setNewSquadName(e.target.value)}
                  placeholder="e.g. Quantum Physics Sprint Group or NEET Bio Masters"
                  className="mt-1 w-full px-3.5 py-2.5 rounded-xl text-xs bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-gray-900 dark:text-white"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
                  Focus Subject Track:
                </label>
                <select
                  value={newSquadSubject}
                  onChange={(e) => setNewSquadSubject(e.target.value)}
                  className="mt-1 w-full px-3.5 py-2.5 rounded-xl text-xs bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-gray-900 dark:text-white"
                >
                  <option value="Programming">Programming & Computer Science</option>
                  <option value="Physics">Physics & Mechanics</option>
                  <option value="Mathematics">Mathematics & Calculus</option>
                  <option value="Biology">Biology & Medical Entrance</option>
                  <option value="Chemistry">Chemistry</option>
                  <option value="Commerce">Commerce & Accounting</option>
                  <option value="General Academic">General Academic</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
                  Squad Purpose & Rules:
                </label>
                <textarea
                  value={newSquadDesc}
                  onChange={(e) => setNewSquadDesc(e.target.value)}
                  rows={3}
                  placeholder="e.g. Daily 2-hour problem solving sprints. Share milestones and keep each other motivated."
                  className="mt-1 w-full px-3.5 py-2.5 rounded-xl text-xs bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-gray-900 dark:text-white"
                />
              </div>

              <div className="flex items-center space-x-3 p-3 rounded-xl bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D]">
                <input
                  type="checkbox"
                  id="privacy"
                  checked={isPrivate}
                  onChange={(e) => setIsPrivate(e.target.checked)}
                  className="w-4 h-4 rounded accent-teal-600"
                />
                <label htmlFor="privacy" className="text-xs text-gray-700 dark:text-gray-300 cursor-pointer">
                  <strong>Make this Squad Private</strong> (Only members with the invitation code can join)
                </label>
              </div>

              <button
                type="submit"
                disabled={creating}
                className="w-full py-3.5 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow-lg shadow-teal-600/30 transition-all flex items-center justify-center gap-2"
              >
                {creating ? "Creating Squad..." : "Launch Study Squad & Generate Invite Code"}
              </button>
            </form>
          </div>
        )}
      </div>
    </AppShell>
  );
}

