const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export interface UserProfile {
  id: string;
  full_name: string;
  email?: string;
  grade_stream: string;
  focus_span_minutes: number;
  school_start_time: string;
  school_end_time: string;
  sleep_start_time: string;
  peak_energy: string;
  created_at?: string;
  total_xp?: number;
  current_level?: number;
  tier?: string;
  badges_json?: string;
  daily_task_goal?: number;
}

export interface PlannerTask {
  id: number;
  student_id: string;
  topic_name: string;
  scheduled_date: string;
  duration_minutes: number;
  is_completed: boolean;
  is_missed: boolean;
  subject?: string;
}

export interface AnalyticsData {
  student_id: string;
  total_tasks: number;
  completed_tasks: number;
  completion_rate: number;
  streak_days: number;
  backlog_count: number;
  heatmap: Record<string, number>;
  total_xp?: number;
  current_level?: number;
  current_level_xp?: number;
  next_level_xp?: number;
  progress_percentage?: number;
  tier?: string;
  badges_count?: number;
}

export interface Flashcard {
  front: string;
  back: string;
}

export interface FlashcardSetItem {
  id: number;
  topic: string;
  image_path?: string;
  cards: Flashcard[];
  next_review_date: string;
  srs_interval: number;
  created_at: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correct_index: number;
  explanation: string;
}

export interface SkillNodeItem {
  id: string;
  track: string;
  title: string;
  level_order: number;
  is_unlocked: boolean;
  quiz: QuizQuestion[];
}

export interface PodLeaderboardItem {
  rank: number;
  student_id: string;
  student_name: string;
  tasks_completed_count: number;
  last_active: string;
}

// --- FEATURE 1: SUBJECT PROGRESS INTERFACES ---
export interface SubjectProgressItem {
  subject: string;
  completed_today: number;
  remaining_today: number;
  daily_goal: number;
  remaining_against_goal: number;
  completion_percentage: number;
  all_time_completed: number;
  all_time_total: number;
}

export interface SubjectProgressData {
  student_id: string;
  date: string;
  subjects: SubjectProgressItem[];
  summary: {
    total_completed: number;
    total_remaining: number;
    total_goal: number;
    overall_goal_percentage: number;
  };
}

// --- FEATURE 2: GAMIFICATION & PROGRESSION INTERFACES ---
export interface BadgeInfo {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: string;
  awarded_at?: string;
}

export interface GamificationProfile {
  student_id: string;
  full_name: string;
  total_xp: number;
  current_level: number;
  current_level_xp: number;
  next_level_xp: number;
  progress_percentage: number;
  tier: string;
  badge_ids: string[];
  badges: BadgeInfo[];
  all_badges: BadgeInfo[];
}

export interface ToggleTaskResponse {
  message: string;
  task: PlannerTask;
  xp_earned: number;
  total_xp: number;
  current_level: number;
  current_level_xp: number;
  next_level_xp: number;
  progress_percentage: number;
  tier: string;
  leveled_up: boolean;
  tier_upgraded: boolean;
  new_badges: BadgeInfo[];
  badges: string[];
}

// --- FEATURE 3: SOCIAL SQUADS INTERFACES ---
export interface StudySquad {
  id: number;
  name: string;
  code: string;
  description: string;
  focus_subject: string;
  creator_id: string;
  creator_name: string;
  is_private: boolean;
  created_at: string;
  member_count: number;
  is_member: boolean;
  top_members?: Array<{ name: string; xp: number; role: string }>;
}

export interface SquadMemberDetail {
  student_id: string;
  student_name: string;
  role: string;
  xp_contributed: number;
  joined_at: string;
}

export interface SquadFeedItem {
  id: number;
  squad_id: number;
  student_id: string;
  student_name: string;
  activity_type: string;
  content: string;
  badge_name?: string;
  created_at: string;
  reactions: Record<string, number>;
  reacted_users: Record<string, string[]>;
}

export interface SquadFeedResponse {
  squad: StudySquad & { members: SquadMemberDetail[] };
  feed: SquadFeedItem[];
}

// --- FEATURE 4: GLOBAL LEADERBOARD INTERFACES ---
export interface GlobalLeaderboardEntry {
  rank: number;
  student_id: string;
  student_name: string;
  grade_stream: string;
  total_xp: number;
  tasks_completed: number;
  streak_days: number;
  level: number;
  tier: string;
  avatar: string;
  is_current_user: boolean;
}

export interface GlobalUserStanding {
  rank: number;
  total_participants: number;
  percentile: number;
  tier: string;
  total_xp: number;
  tasks_completed: number;
  streak_days: number;
  xp_to_next_rank: number;
  next_scholar_name: string | null;
}

export interface GlobalLeaderboardData {
  metric: string;
  timeframe: string;
  total_scholars_count: number;
  user_standing: GlobalUserStanding | null;
  podium: GlobalLeaderboardEntry[];
  leaderboard: GlobalLeaderboardEntry[];
}

// Local Storage helpers for dynamic user identity
export function getStoredUserId(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("study_buddy_user_id");
}

export function setStoredUserId(id: string): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("study_buddy_user_id", id);
  }
}

export function getStoredProfile(): UserProfile | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem("study_buddy_profile");
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function setStoredProfile(profile: UserProfile): void {
  if (typeof window !== "undefined") {
    localStorage.setItem("study_buddy_profile", JSON.stringify(profile));
  }
}

export function clearUserSession(): void {
  if (typeof window !== "undefined") {
    localStorage.removeItem("study_buddy_user_id");
    localStorage.removeItem("study_buddy_profile");
  }
}

// --- CORE API CLIENT METHODS ---

export async function fetchProfile(studentId?: string): Promise<UserProfile> {
  const id = studentId || getStoredUserId();
  if (!id) throw new Error("No active student ID");
  const res = await fetch(`${API_BASE}/api/onboarding/profile/${id}`);
  if (!res.ok) throw new Error("Failed to fetch profile");
  return res.json();
}

export async function saveProfile(data: Partial<UserProfile>): Promise<{ message: string; user_id: string; profile: UserProfile }> {
  const res = await fetch(`${API_BASE}/api/onboarding/profile`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Failed to save profile");
  return res.json();
}

export async function fetchTasks(studentId?: string): Promise<PlannerTask[]> {
  const id = studentId || getStoredUserId();
  if (!id) return [];
  const res = await fetch(`${API_BASE}/api/planner/tasks/${id}`);
  if (!res.ok) throw new Error("Failed to fetch tasks");
  return res.json();
}

export async function generateRoadmap(payload: {
  student_id?: string;
  target_goal: string;
  deadline_date: string;
  daily_hours: number;
}): Promise<any> {
  const id = payload.student_id || getStoredUserId();
  if (!id) throw new Error("User must complete onboarding first");

  const res = await fetch(`${API_BASE}/api/planner/generate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      student_id: id,
      target_goal: payload.target_goal,
      deadline_date: payload.deadline_date,
      daily_hours: payload.daily_hours,
    }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Failed to generate roadmap");
  }
  return res.json();
}

export async function rescheduleBacklogs(studentId?: string): Promise<any> {
  const id = studentId || getStoredUserId();
  if (!id) throw new Error("No active student ID");
  const res = await fetch(`${API_BASE}/api/planner/reschedule-missed/${id}`, {
    method: "POST",
  });
  if (!res.ok) throw new Error("Failed to reschedule backlogs");
  return res.json();
}

// TOGGLE TASK WITH FULL PROGRESSION RESPONSE
export async function toggleTask(taskId: number, isCompleted?: boolean): Promise<ToggleTaskResponse> {
  const res = await fetch(`${API_BASE}/api/planner/tasks/${taskId}/toggle`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(isCompleted !== undefined ? { is_completed: isCompleted } : {}),
  });
  if (!res.ok) throw new Error("Failed to toggle task");
  const data: ToggleTaskResponse = await res.json();
  
  // Dispatch a browser-level custom event so TopHeader and widgets update immediately
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("study_buddy_gamification_update", {
        detail: data,
      })
    );
  }

  return data;
}

export async function fetchAnalytics(studentId?: string): Promise<AnalyticsData> {
  const id = studentId || getStoredUserId();
  if (!id) {
    return {
      student_id: "",
      total_tasks: 0,
      completed_tasks: 0,
      completion_rate: 0,
      streak_days: 0,
      backlog_count: 0,
      heatmap: {},
      total_xp: 0,
      current_level: 1,
      current_level_xp: 0,
      next_level_xp: 100,
      progress_percentage: 0,
      tier: "Bronze Scholar",
    };
  }
  const res = await fetch(`${API_BASE}/api/planner/analytics/${id}`);
  if (!res.ok) throw new Error("Failed to fetch analytics");
  return res.json();
}

// --- FEATURE 1: SUBJECT-WISE PROGRESSION API ---
export async function fetchSubjectProgress(studentId?: string): Promise<SubjectProgressData> {
  const id = studentId || getStoredUserId();
  if (!id) {
    return {
      student_id: "",
      date: new Date().toISOString().split("T")[0],
      subjects: [],
      summary: { total_completed: 0, total_remaining: 0, total_goal: 0, overall_goal_percentage: 0 },
    };
  }
  const res = await fetch(`${API_BASE}/api/planner/subjects/${id}`);
  if (!res.ok) throw new Error("Failed to fetch subject progress");
  return res.json();
}

// --- FEATURE 2: GAMIFICATION PROFILE API ---
export async function fetchGamificationProfile(studentId?: string): Promise<GamificationProfile> {
  const id = studentId || getStoredUserId();
  if (!id) throw new Error("No active student ID");
  const res = await fetch(`${API_BASE}/api/gamification/profile/${id}`);
  if (!res.ok) throw new Error("Failed to fetch gamification profile");
  return res.json();
}

// --- FEATURE 3: STUDY SQUADS & SOCIAL API ---
export async function fetchSquads(studentId?: string): Promise<{ squads: StudySquad[] }> {
  const id = studentId || getStoredUserId();
  const url = id ? `${API_BASE}/api/social/squads?student_id=${id}` : `${API_BASE}/api/social/squads`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Failed to fetch study squads");
  return res.json();
}

export async function createSquad(data: {
  name: string;
  description?: string;
  focus_subject?: string;
  creator_id?: string;
  creator_name?: string;
  is_private?: boolean;
}): Promise<{ message: string; squad: StudySquad }> {
  const id = data.creator_id || getStoredUserId() || "student-temp";
  const name = data.creator_name || getStoredProfile()?.full_name || "Scholar";
  const res = await fetch(`${API_BASE}/api/social/squads`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...data, creator_id: id, creator_name: name }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Failed to create squad");
  }
  return res.json();
}

export async function joinSquad(code: string, studentName?: string, studentId?: string): Promise<any> {
  const id = studentId || getStoredUserId() || "student-temp";
  const name = studentName || getStoredProfile()?.full_name || "Scholar";
  const res = await fetch(`${API_BASE}/api/social/squads/join`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code, student_id: id, student_name: name }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Failed to join squad");
  }
  return res.json();
}

export async function fetchSquadFeed(squadId: number): Promise<SquadFeedResponse> {
  const res = await fetch(`${API_BASE}/api/social/squads/${squadId}/feed`);
  if (!res.ok) throw new Error("Failed to fetch squad feed");
  return res.json();
}

export async function postToSquadFeed(
  squadId: number,
  data: {
    student_id?: string;
    student_name?: string;
    content: string;
    activity_type?: string;
    badge_name?: string;
  }
): Promise<any> {
  const id = data.student_id || getStoredUserId() || "student-temp";
  const name = data.student_name || getStoredProfile()?.full_name || "Scholar";
  const res = await fetch(`${API_BASE}/api/social/squads/${squadId}/feed`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...data, student_id: id, student_name: name }),
  });
  if (!res.ok) throw new Error("Failed to post to squad feed");
  return res.json();
}

export async function reactToFeedItem(itemId: number, reaction: string, studentId?: string): Promise<any> {
  const id = studentId || getStoredUserId() || "student-temp";
  const res = await fetch(`${API_BASE}/api/social/feed/${itemId}/react`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ student_id: id, reaction }),
  });
  if (!res.ok) throw new Error("Failed to react to feed item");
  return res.json();
}

// --- FEATURE 4: GLOBAL LEADERBOARD API ---
export async function fetchGlobalLeaderboard(
  metric: string = "xp",
  timeframe: string = "all",
  studentId?: string
): Promise<GlobalLeaderboardData> {
  const id = studentId || getStoredUserId();
  const query = new URLSearchParams({ metric, timeframe });
  if (id) query.set("student_id", id);

  const res = await fetch(`${API_BASE}/api/social/leaderboard/global?${query.toString()}`);
  if (!res.ok) throw new Error("Failed to fetch global leaderboard");
  return res.json();
}

// OTHER MODULE HELPERS
export async function snapSolveDoubt(formData: FormData): Promise<any> {
  const res = await fetch(`${API_BASE}/api/doubts/snap-solve`, {
    method: "POST",
    body: formData,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Failed to solve doubt snapshot");
  }
  return res.json();
}

export async function fetchFlashcards(studentId?: string): Promise<FlashcardSetItem[]> {
  const id = studentId || getStoredUserId();
  if (!id) return [];
  const res = await fetch(`${API_BASE}/api/doubts/flashcards/${id}`);
  if (!res.ok) throw new Error("Failed to fetch flashcards");
  return res.json();
}

export async function analyzeYoutubeVideo(url: string): Promise<any> {
  const res = await fetch(`${API_BASE}/api/youtube/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Failed to analyze YouTube video");
  }
  return res.json();
}

export async function explainTeacherNotes(formData: FormData): Promise<any> {
  const res = await fetch(`${API_BASE}/api/teacher/explain`, {
    method: "POST",
    body: formData,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Failed to generate teacher explanation");
  }
  return res.json();
}

export async function fetchSkillTracks(): Promise<{ tracks: string[] }> {
  const res = await fetch(`${API_BASE}/api/skills/tracks`);
  if (!res.ok) throw new Error("Failed to fetch skill tracks");
  return res.json();
}

export async function fetchSkillTree(track: string): Promise<SkillNodeItem[]> {
  const res = await fetch(`${API_BASE}/api/skills/tree/${encodeURIComponent(track)}`);
  if (!res.ok) throw new Error("Failed to fetch skill tree");
  return res.json();
}

export async function submitSkillQuiz(nodeId: string, scorePercentage: number): Promise<any> {
  const res = await fetch(`${API_BASE}/api/skills/submit-quiz`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ node_id: nodeId, score_percentage: scorePercentage }),
  });
  if (!res.ok) throw new Error("Failed to submit quiz");
  return res.json();
}

export async function fetchPodLeaderboard(roomCode: string = "FOCUS-2026"): Promise<{
  room_code: string;
  active_students_count: number;
  leaderboard: PodLeaderboardItem[];
}> {
  const res = await fetch(`${API_BASE}/api/pods/leaderboard/${roomCode}`);
  if (!res.ok) throw new Error("Failed to fetch pod leaderboard");
  return res.json();
}

export async function joinPodRoom(roomCode: string, studentName?: string, studentId?: string): Promise<any> {
  const id = studentId || getStoredUserId() || "student-temp";
  const name = studentName || getStoredProfile()?.full_name || "Scholar";
  const res = await fetch(`${API_BASE}/api/pods/join`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ room_code: roomCode, student_name: name, student_id: id }),
  });
  if (!res.ok) throw new Error("Failed to join pod");
  return res.json();
}

export { API_BASE };
