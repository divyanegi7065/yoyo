"use client";

import React, { useState, useEffect } from "react";
import {
  SubjectProgressData,
  SubjectProgressItem,
  fetchSubjectProgress,
  getStoredUserId,
  PlannerTask,
} from "@/lib/api";
import {
  BookOpen,
  CheckCircle2,
  Clock,
  Target,
  Sparkles,
  TrendingUp,
  Award,
  Layers,
  ArrowUpRight,
} from "lucide-react";

interface SubjectProgressWidgetProps {
  initialData?: SubjectProgressData | null;
  tasks?: PlannerTask[];
}

// Subject color map for visual distinction
const SUBJECT_COLORS: Record<
  string,
  { bg: string; fill: string; border: string; text: string; icon: string }
> = {
  Physics: {
    bg: "bg-cyan-500/10 dark:bg-cyan-500/15",
    fill: "bg-cyan-500",
    border: "border-cyan-500/30",
    text: "text-cyan-600 dark:text-cyan-400",
    icon: "⚛️",
  },
  Mathematics: {
    bg: "bg-purple-500/10 dark:bg-purple-500/15",
    fill: "bg-purple-500",
    border: "border-purple-500/30",
    text: "text-purple-600 dark:text-purple-400",
    icon: "📐",
  },
  Programming: {
    bg: "bg-teal-500/10 dark:bg-teal-500/15",
    fill: "bg-teal-500",
    border: "border-teal-500/30",
    text: "text-teal-600 dark:text-teal-400",
    icon: "💻",
  },
  Biology: {
    bg: "bg-emerald-500/10 dark:bg-emerald-500/15",
    fill: "bg-emerald-500",
    border: "border-emerald-500/30",
    text: "text-emerald-600 dark:text-emerald-400",
    icon: "🧬",
  },
  Chemistry: {
    bg: "bg-amber-500/10 dark:bg-amber-500/15",
    fill: "bg-amber-500",
    border: "border-amber-500/30",
    text: "text-amber-600 dark:text-amber-400",
    icon: "🧪",
  },
  Commerce: {
    bg: "bg-blue-500/10 dark:bg-blue-500/15",
    fill: "bg-blue-500",
    border: "border-blue-500/30",
    text: "text-blue-600 dark:text-blue-400",
    icon: "📊",
  },
  Humanities: {
    bg: "bg-rose-500/10 dark:bg-rose-500/15",
    fill: "bg-rose-500",
    border: "border-rose-500/30",
    text: "text-rose-600 dark:text-rose-400",
    icon: "📚",
  },
};

const DEFAULT_COLOR = {
  bg: "bg-teal-500/10 dark:bg-teal-500/15",
  fill: "bg-teal-500",
  border: "border-teal-500/30",
  text: "text-teal-600 dark:text-teal-400",
  icon: "🎯",
};

export default function SubjectProgressWidget({
  initialData,
  tasks,
}: SubjectProgressWidgetProps) {
  const [data, setData] = useState<SubjectProgressData | null>(initialData || null);
  const [loading, setLoading] = useState(!initialData);
  const [customGoal, setCustomGoal] = useState<number>(2);

  const loadProgress = async () => {
    const userId = getStoredUserId();
    if (!userId) return;
    try {
      const res = await fetchSubjectProgress(userId);
      setData(res);
    } catch (err) {
      console.error("Subject progress load error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProgress();

    // Listen to real-time gamification updates whenever any task is toggled
    const handleGamificationUpdate = () => {
      loadProgress();
    };

    window.addEventListener("study_buddy_gamification_update", handleGamificationUpdate);
    return () => {
      window.removeEventListener("study_buddy_gamification_update", handleGamificationUpdate);
    };
  }, []);

  // Also reload when tasks prop changes
  useEffect(() => {
    if (tasks) {
      loadProgress();
    }
  }, [tasks]);

  const subjects = data?.subjects || [];
  const summary = data?.summary || {
    total_completed: 0,
    total_remaining: 0,
    total_goal: 0,
    overall_goal_percentage: 0,
  };

  // Find top active subject
  const topSubject = [...subjects].sort(
    (a, b) => b.completed_today - a.completed_today
  )[0];

  return (
    <div className="p-6 rounded-3xl bg-white dark:bg-[#0F172A] border border-gray-200 dark:border-[#1E333D] shadow-sm space-y-6">
      {/* Widget Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-gray-100 dark:border-[#1E333D] gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400 flex items-center justify-center">
            <Layers className="w-5 h-5 text-salmon-500" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <span>Real-Time Subject Progress Dashboard</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 border border-teal-500/20">
                Live Sync
              </span>
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Completed vs remaining daily tasks against predefined subject targets
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-gray-400 font-medium hidden sm:inline">Daily Target:</span>
          <div className="flex items-center bg-gray-100 dark:bg-[#13232C] p-1 rounded-xl border border-gray-200 dark:border-[#1E333D]">
            {[1, 2, 3].map((g) => (
              <button
                key={g}
                onClick={() => setCustomGoal(g)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  customGoal === g
                    ? "bg-teal-600 text-white shadow-sm"
                    : "text-gray-500 hover:text-gray-800 dark:hover:text-white"
                }`}
              >
                {g} / subj
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Side-by-Side Graphical Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left Side (8 Columns): Graphical Stacked Bars & Progress Rings */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-500 dark:text-gray-400 px-1">
            <span>Subject & Breakdown</span>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-teal-500" />
                <span>Completed</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400/70" />
                <span>Remaining Goal</span>
              </span>
            </div>
          </div>

          <div className="space-y-3">
            {subjects.length === 0 ? (
              <div className="py-8 text-center text-xs text-gray-400 border border-dashed border-gray-200 dark:border-[#1E333D] rounded-2xl">
                No active subjects mapped for today. Plan new tasks to see live charts.
              </div>
            ) : (
              subjects.map((item) => {
                const colorConfig = SUBJECT_COLORS[item.subject] || DEFAULT_COLOR;
                // Effective goal considering custom goal
                const effectiveGoal = Math.max(item.daily_goal, customGoal, item.completed_today + item.remaining_today);
                const completedCount = item.completed_today;
                const remainingCount = Math.max(0, effectiveGoal - completedCount);
                const completedPct = effectiveGoal > 0 ? Math.min(100, Math.round((completedCount / effectiveGoal) * 100)) : 0;
                const remainingPct = 100 - completedPct;

                return (
                  <div
                    key={item.subject}
                    className="p-4 rounded-2xl bg-gray-50 dark:bg-[#13232C]/60 border border-gray-200 dark:border-[#1E333D] transition-all hover:border-teal-500/50 group"
                  >
                    {/* Top Row: Icon, Subject Title, Numeric Badge */}
                    <div className="flex items-center justify-between mb-2.5">
                      <div className="flex items-center space-x-2.5">
                        <span className="text-base">{colorConfig.icon}</span>
                        <div>
                          <div className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                            <span>{item.subject}</span>
                            {completedCount >= effectiveGoal && effectiveGoal > 0 && (
                              <span className="text-[10px] px-2 py-0.2 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 font-bold border border-teal-500/30 flex items-center gap-0.5">
                                <CheckCircle2 className="w-3 h-3 text-teal-500" /> Goal Met
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-gray-400">
                            {item.all_time_completed} all-time completed • {item.remaining_today} due today
                          </div>
                        </div>
                      </div>

                      {/* Side metrics tag */}
                      <div className="text-right">
                        <div className="text-xs font-mono font-extrabold text-gray-900 dark:text-white">
                          <span className={colorConfig.text}>{completedCount}</span>
                          <span className="text-gray-400 font-normal"> / {effectiveGoal} Done</span>
                        </div>
                        <span className="text-[10px] font-bold text-salmon-500">
                          {completedPct}%
                        </span>
                      </div>
                    </div>

                    {/* Dynamic Stacked Bar Chart */}
                    <div className="space-y-1">
                      <div className="w-full h-3.5 bg-gray-200 dark:bg-[#1E333D] rounded-full overflow-hidden flex relative shadow-inner">
                        {/* Completed segment */}
                        <div
                          style={{ width: `${completedPct}%` }}
                          className={`h-full ${colorConfig.fill} transition-all duration-500 ease-out flex items-center justify-end pr-1 text-[9px] font-bold text-white`}
                        >
                          {completedPct >= 20 && `${completedCount}`}
                        </div>

                        {/* Remaining to goal segment */}
                        {remainingCount > 0 && (
                          <div
                            style={{ width: `${remainingPct}%` }}
                            className="h-full bg-amber-400/40 dark:bg-amber-500/25 border-l border-white/20 dark:border-[#0F172A]/40 transition-all duration-500 flex items-center justify-center text-[9px] font-bold text-amber-700 dark:text-amber-300"
                          >
                            {remainingPct >= 25 && `${remainingCount} left`}
                          </div>
                        )}
                      </div>

                      {/* Micro progress indicator labels */}
                      <div className="flex justify-between text-[10px] text-gray-400 font-mono px-0.5">
                        <span>0</span>
                        <span>Target: {effectiveGoal} Tasks</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Side (4 Columns): Productivity Velocity & Focus Gauge */}
        <div className="lg:col-span-4 flex flex-col justify-between gap-4 p-5 rounded-2xl bg-gradient-to-br from-teal-50 to-teal-100/50 dark:from-[#0F2228] dark:to-[#0B171C] border border-teal-200 dark:border-teal-900/60 shadow-sm">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-teal-200 dark:border-teal-800/60">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-salmon-500" />
                <span>Daily Subject Velocity</span>
              </span>
              <span className="text-[10px] font-mono text-gray-400">Today</span>
            </div>

            {/* Circular Progress Gauge */}
            <div className="my-5 flex flex-col items-center">
              <div className="relative w-28 h-28 flex items-center justify-center">
                {/* SVG Progress Ring */}
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    className="stroke-gray-200 dark:stroke-[#1E333D]"
                    strokeWidth="10"
                    fill="transparent"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    className="stroke-teal-600 dark:stroke-teal-400 transition-all duration-700 ease-out"
                    strokeWidth="10"
                    strokeDasharray={251.2}
                    strokeDashoffset={
                      251.2 - (251.2 * (summary.overall_goal_percentage || 0)) / 100
                    }
                    strokeLinecap="round"
                    fill="transparent"
                  />
                </svg>
                {/* Center text */}
                <div className="absolute flex flex-col items-center">
                  <span className="text-2xl font-extrabold text-gray-900 dark:text-white">
                    {summary.overall_goal_percentage}%
                  </span>
                  <span className="text-[9px] uppercase tracking-wider font-bold text-gray-400">
                    Goal Met
                  </span>
                </div>
              </div>

              <div className="mt-2 text-center">
                <div className="text-xs font-extrabold text-teal-800 dark:text-teal-200">
                  {summary.total_completed} of {Math.max(summary.total_goal, summary.total_completed + summary.total_remaining)} Daily Tasks
                </div>
                <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">
                  {summary.total_remaining > 0
                    ? `${summary.total_remaining} sprints remaining for target`
                    : "🎉 All daily subject goals achieved!"}
                </p>
              </div>
            </div>
          </div>

          {/* Quick Metrics Breakdown Box */}
          <div className="space-y-2 pt-3 border-t border-teal-200 dark:border-teal-800/60 text-xs">
            <div className="flex items-center justify-between text-gray-600 dark:text-gray-300">
              <span className="flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-salmon-500" />
                <span>Top Focus Subject:</span>
              </span>
              <span className="font-bold text-teal-700 dark:text-teal-300">
                {topSubject ? topSubject.subject : "N/A"}
              </span>
            </div>

            <div className="flex items-center justify-between text-gray-600 dark:text-gray-300">
              <span className="flex items-center gap-1">
                <Target className="w-3.5 h-3.5 text-teal-500" />
                <span>Active Subjects:</span>
              </span>
              <span className="font-mono font-bold text-gray-800 dark:text-gray-200">
                {subjects.length} Streams
              </span>
            </div>

            <div className="flex items-center justify-between text-gray-600 dark:text-gray-300">
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-500" />
                <span>Remaining Sprints:</span>
              </span>
              <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                {summary.total_remaining} Sprints
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

