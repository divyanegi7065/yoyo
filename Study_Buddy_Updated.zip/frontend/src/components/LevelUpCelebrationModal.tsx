"use client";

import React, { useEffect, useState } from "react";
import { Award, Sparkles, X, ChevronRight, Zap, Trophy, ShieldCheck } from "lucide-react";
import { BadgeInfo } from "@/lib/api";

interface LevelUpCelebrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  newLevel: number;
  tier: string;
  totalXp: number;
  newBadges: BadgeInfo[];
  tierUpgraded?: boolean;
}

export default function LevelUpCelebrationModal({
  isOpen,
  onClose,
  newLevel,
  tier,
  totalXp,
  newBadges = [],
  tierUpgraded = false,
}: LevelUpCelebrationModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#0F172A] border-2 border-salmon-500/40 shadow-2xl overflow-hidden text-center space-y-6 animate-scale-up">
        {/* Glow ambient background aura */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-salmon-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-teal-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-gray-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-[#1E333D] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Level Emblem / Crown Icon */}
        <div className="relative mx-auto w-24 h-24 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-salmon-500 to-amber-400 animate-ping opacity-25" />
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-salmon-500 via-rose-500 to-amber-400 flex items-center justify-center shadow-xl shadow-salmon-500/40 border-4 border-white dark:border-[#0F172A]">
            <Trophy className="w-12 h-12 text-white animate-bounce-gentle" />
          </div>
        </div>

        {/* Main Headings */}
        <div className="space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-salmon-500/10 text-salmon-500 border border-salmon-500/30 text-xs font-extrabold uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Progression Milestone Achieved</span>
          </div>

          <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight mt-2">
            Level Up! You Reached <span className="text-salmon-500">Level {newLevel}</span>
          </h2>

          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 max-w-sm mx-auto">
            Your daily study sprints and completed goals have elevated your academic standing!
          </p>
        </div>

        {/* Tier Banner */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-teal-500/10 via-teal-500/20 to-teal-500/10 border border-teal-500/30 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2 text-left">
            <ShieldCheck className="w-5 h-5 text-teal-600 dark:text-teal-400 flex-shrink-0" />
            <div>
              <div className="text-[10px] uppercase font-bold text-teal-600 dark:text-teal-400">
                {tierUpgraded ? "Tier Promotion Unlocked!" : "Active Academic Tier"}
              </div>
              <div className="text-sm font-extrabold text-gray-900 dark:text-white">
                {tier}
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-[10px] text-gray-400 uppercase font-semibold">Total XP</div>
            <div className="text-sm font-mono font-extrabold text-teal-600 dark:text-teal-400">
              {totalXp} XP
            </div>
          </div>
        </div>

        {/* Newly Awarded Badges Showcase */}
        {newBadges.length > 0 && (
          <div className="space-y-2 text-left">
            <div className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-salmon-500" />
              <span>Newly Unlocked Badges ({newBadges.length})</span>
            </div>

            <div className="space-y-2 max-h-36 overflow-y-auto">
              {newBadges.map((b) => (
                <div
                  key={b.id}
                  className="p-3 rounded-xl bg-gray-50 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] flex items-center space-x-3"
                >
                  <span className="text-2xl">{b.icon}</span>
                  <div>
                    <div className="text-xs font-bold text-gray-900 dark:text-white">
                      {b.title}
                    </div>
                    <div className="text-[11px] text-gray-500 dark:text-gray-400">
                      {b.description}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={onClose}
          className="w-full py-3.5 rounded-2xl bg-salmon-500 hover:bg-salmon-600 text-white font-extrabold text-sm shadow-xl shadow-salmon-500/30 transition-all transform active:scale-95 flex items-center justify-center gap-2"
        >
          <span>Claim Rewards & Keep Crushing</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

