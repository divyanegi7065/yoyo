"use client";

import React, { useEffect, useState } from "react";
import { Flame, Moon, Sun, GraduationCap, Clock, Award, Zap, Shield } from "lucide-react";
import { UserProfile, ToggleTaskResponse } from "@/lib/api";

interface TopHeaderProps {
  profile?: UserProfile | null;
  streakDays?: number;
}

export default function TopHeader({ profile, streakDays = 0 }: TopHeaderProps) {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [level, setLevel] = useState<number>(profile?.current_level || 1);
  const [tier, setTier] = useState<string>(profile?.tier || "Bronze Scholar");
  const [totalXp, setTotalXp] = useState<number>(profile?.total_xp || 0);
  const [progressPct, setProgressPct] = useState<number>(0);
  const [currentLevelXp, setCurrentLevelXp] = useState<number>(0);
  const [nextLevelXp, setNextLevelXp] = useState<number>(100);

  useEffect(() => {
    // Check saved theme or system preference
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
      setIsDarkMode(false);
      document.documentElement.classList.remove("dark");
    } else {
      setIsDarkMode(true);
      document.documentElement.classList.add("dark");
    }
  }, []);

  useEffect(() => {
    if (profile) {
      setLevel(profile.current_level || 1);
      setTier(profile.tier || "Bronze Scholar");
      setTotalXp(profile.total_xp || 0);
      const needed = 100 * (profile.current_level || 1);
      setNextLevelXp(needed);
    }
  }, [profile]);

  useEffect(() => {
    // Listen to real-time gamification updates
    const handleGamificationUpdate = (e: Event) => {
      const customEvent = e as CustomEvent<ToggleTaskResponse>;
      if (customEvent.detail) {
        const detail = customEvent.detail;
        setLevel(detail.current_level);
        setTier(detail.tier);
        setTotalXp(detail.total_xp);
        setProgressPct(detail.progress_percentage);
        setCurrentLevelXp(detail.current_level_xp);
        setNextLevelXp(detail.next_level_xp);
      }
    };

    window.addEventListener("study_buddy_gamification_update", handleGamificationUpdate);
    return () => {
      window.removeEventListener("study_buddy_gamification_update", handleGamificationUpdate);
    };
  }, []);

  const toggleTheme = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
      setIsDarkMode(true);
    }
  };

  return (
    <header className="h-16 px-6 bg-white/80 dark:bg-[#0F172A]/90 backdrop-blur-md border-b border-gray-200 dark:border-[#1E333D] flex items-center justify-between sticky top-0 z-30 transition-colors">
      <div className="flex items-center space-x-3">
        <h2 className="text-sm font-bold text-gray-800 dark:text-gray-200 hidden sm:block">
          AI Academic OS
        </h2>
        <span className="hidden sm:inline-block text-xs px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-600 dark:text-teal-400 font-semibold border border-teal-500/20">
          Groq Llama 3.3 Core
        </span>
      </div>

      <div className="flex items-center space-x-3 sm:space-x-4">
        {/* Real-Time Level & XP Progression Pill */}
        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-teal-500/10 dark:bg-teal-500/15 border border-teal-500/30 text-teal-700 dark:text-teal-300 shadow-sm transition-all">
          <div className="w-6 h-6 rounded-lg bg-teal-600 text-white font-extrabold text-[11px] flex items-center justify-center shadow-xs">
            L{level}
          </div>
          <div className="hidden lg:flex flex-col text-left">
            <div className="flex items-center gap-1.5 text-[10px] font-bold">
              <span>{tier}</span>
              <span className="text-gray-400 font-mono">({totalXp} XP)</span>
            </div>
            {/* Micro XP Progress Bar */}
            <div className="w-24 h-1.5 bg-gray-200 dark:bg-[#1E333D] rounded-full overflow-hidden mt-0.5">
              <div
                style={{ width: `${progressPct}%` }}
                className="h-full bg-teal-500 rounded-full transition-all duration-500"
              />
            </div>
          </div>
        </div>

        {/* Streak Counter with Salmon Pink Flame */}
        <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-salmon-500/10 dark:bg-salmon-500/15 border border-salmon-500/30 text-salmon-500 font-bold text-xs sm:text-sm shadow-sm animate-pulse-slow">
          <Flame className="w-4 h-4 text-salmon-500 fill-salmon-500" />
          <span>{streakDays}d Streak</span>
        </div>

        {/* Academic Profile Badge */}
        <div className="hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-gray-100 dark:bg-[#13232C] border border-gray-200 dark:border-[#1E333D] text-xs">
          <GraduationCap className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          <span className="font-semibold text-gray-700 dark:text-gray-200">
            {profile?.grade_stream || "Class 11 Science"}
          </span>
          <span className="text-gray-400">•</span>
          <span className="text-gray-500 dark:text-gray-400 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {profile?.focus_span_minutes || 45}m
          </span>
        </div>

        {/* Dark / Light Toggle */}
        <button
          onClick={toggleTheme}
          aria-label="Toggle Dark Mode"
          className="p-2 rounded-xl bg-gray-100 dark:bg-[#13232C] hover:bg-gray-200 dark:hover:bg-[#1E333D] text-gray-600 dark:text-gray-300 transition-colors border border-gray-200 dark:border-[#1E333D]"
        >
          {isDarkMode ? (
            <Sun className="w-4 h-4 text-salmon-400" />
          ) : (
            <Moon className="w-4 h-4 text-teal-600" />
          )}
        </button>
      </div>
    </header>
  );
}
