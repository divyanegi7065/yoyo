import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parent))

from database import engine, init_db
from sqlmodel import Session, select
from seed_data import seed_database
from models import (
    UserProfile,
    PlannerTask,
    SkillNode,
    StudySquad,
    SquadMember,
    SquadFeedItem
)
from routers.planner import (
    save_or_update_profile,
    get_user_profile,
    get_student_tasks,
    get_planner_analytics,
    generate_schedule,
    reschedule_missed_tasks,
    toggle_task_status,
    get_subject_progress,
    get_gamification_profile,
    ProfileUpdateRequest,
    GenerateRoadmapRequest,
    ToggleTaskRequest
)
from routers.skills import (
    get_available_tracks,
    get_skill_tree,
    submit_skill_quiz,
    QuizSubmission
)
from routers.social import (
    list_squads,
    create_squad,
    join_squad,
    get_squad_feed,
    post_to_squad_feed,
    react_to_feed_item,
    get_global_leaderboard,
    CreateSquadRequest,
    JoinSquadRequest,
    PostFeedItemRequest,
    FeedReactionRequest
)
from services.gamification_service import (
    calculate_progression,
    evaluate_badges,
    get_xp_for_task,
    extract_subject
)
import json

def run_tests():
    print("=================================================================")
    print("      AI STUDY & CAREER BUDDY - FULL VERIFICATION SUITE         ")
    print("=================================================================")

    init_db()
    with Session(engine) as session:
        seed_database(session)

        test_user_id = "test-scholar-101"
        # Clean any test users from prior runs for idempotency
        for u in session.exec(select(UserProfile).where(UserProfile.id == test_user_id)).all():
            session.delete(u)
        for t in session.exec(select(PlannerTask).where(PlannerTask.student_id == test_user_id)).all():
            session.delete(t)
        for sm in session.exec(select(SquadMember).where(SquadMember.student_id == test_user_id)).all():
            session.delete(sm)
        for sq in session.exec(select(StudySquad).where(StudySquad.creator_id == test_user_id)).all():
            # Delete associated members and feed items
            for f in session.exec(select(SquadFeedItem).where(SquadFeedItem.squad_id == sq.id)).all():
                session.delete(f)
            for m in session.exec(select(SquadMember).where(SquadMember.squad_id == sq.id)).all():
                session.delete(m)
            session.delete(sq)
        session.commit()

        # TEST 1: Database Migration & Schema Columns
        profile = UserProfile(id=test_user_id, full_name="Tanvi Deshmukh")
        assert hasattr(profile, "total_xp")
        assert hasattr(profile, "current_level")
        assert hasattr(profile, "tier")
        assert hasattr(profile, "badges_json")
        print("[PASS] 1. Database Schema: Gamification, Squad, and Subject fields verified.")

        # TEST 2: Dynamic User Onboarding
        profile_res = save_or_update_profile(
            ProfileUpdateRequest(
                id=test_user_id,
                full_name="Tanvi Deshmukh",
                email="tanvi@university.edu",
                grade_stream="UG 1st Year B.Tech / CS",
                focus_span_minutes=45,
                school_start_time="09:00",
                school_end_time="16:00",
                sleep_start_time="23:45",
                peak_energy="Late Night",
                daily_task_goal=4
            ),
            session
        )
        assert profile_res["user_id"] == test_user_id
        profile = get_user_profile(test_user_id, session)
        assert profile.full_name == "Tanvi Deshmukh"
        print(f"[PASS] 2. Dynamic Onboarding: User '{profile.full_name}' initialized.")

        # TEST 3: Initial Analytics & Progression State
        analytics = get_planner_analytics(test_user_id, session)
        assert analytics["total_tasks"] == 0
        assert analytics["completed_tasks"] == 0
        assert analytics["streak_days"] == 0
        assert analytics["total_xp"] == 0
        assert analytics["current_level"] == 1
        assert analytics["tier"] == "Bronze Scholar"
        print("[PASS] 3. Initial Analytics & Progression: Level 1, Bronze Tier, 0 XP verified.")

        # TEST 4: Adaptive Planner Generation
        topic = "C++ Data Types & Memory Layout"
        gen_res = generate_schedule(
            GenerateRoadmapRequest(
                student_id=test_user_id,
                target_goal=topic,
                deadline_date="2026-11-08",
                daily_hours=2.0
            ),
            session
        )
        tasks_batch_1 = get_student_tasks(test_user_id, session)
        assert len(tasks_batch_1) > 0
        count_1 = len(tasks_batch_1)
        print(f"[PASS] 4. Topic-Specific Roadmap: Generated {count_1} progressive milestones for '{topic}'.")

        # TEST 5: Task Deduplication on Regenerate
        gen_res_2 = generate_schedule(
            GenerateRoadmapRequest(
                student_id=test_user_id,
                target_goal=topic,
                deadline_date="2026-11-09",
                daily_hours=2.5
            ),
            session
        )
        tasks_batch_2 = get_student_tasks(test_user_id, session)
        assert len(tasks_batch_2) <= count_1 + 2
        print(f"[PASS] 5. Task Deduplication: Cleanly replaced previous uncompleted tasks.")

        # TEST 6: Skill Tree 10 MCQs Expansion
        tracks_res = get_available_tracks(session)
        assert len(tracks_res["tracks"]) >= 3
        for track_name in tracks_res["tracks"]:
            nodes = get_skill_tree(track_name, session)
            assert len(nodes) >= 2
            for n in nodes:
                assert len(n["quiz"]) >= 10
        print("[PASS] 6. Skill Tree Expansion: Every single level node has >= 10 MCQs.")

        # TEST 7: Skill Quiz 80% Threshold Gate
        fail_res = submit_skill_quiz(QuizSubmission(node_id="web-1", score_percentage=70.0), session)
        assert fail_res["passed"] is False
        pass_res = submit_skill_quiz(QuizSubmission(node_id="web-1", score_percentage=85.0), session)
        assert pass_res["passed"] is True
        print(f"[PASS] 7. 80% Threshold Gate: Evaluated passing threshold and unlocked: {pass_res['unlocked_node']}.")

        # TEST 8: FEATURE 1 - Real-Time Subject Progress Graph API
        subj_res = get_subject_progress(test_user_id, session)
        assert "subjects" in subj_res
        assert "summary" in subj_res
        assert len(subj_res["subjects"]) > 0
        prog_subj = next((s for s in subj_res["subjects"] if "Programming" in s["subject"] or "C++" in s["subject"]), subj_res["subjects"][0])
        assert prog_subj["daily_goal"] > 0
        print(f"[PASS] 8. Feature 1: Subject Progress Graph computed {len(subj_res['subjects'])} subject categories.")

        # TEST 9: FEATURE 2 - Gamification Bug Fix & Progression Engine
        # User starts at 0 XP (Level 1). Threshold to Level 2 is 100 XP.
        first_task = tasks_batch_2[0]
        # Complete task 1 (45 mins = 65 XP)
        toggle_1 = toggle_task_status(first_task.id, ToggleTaskRequest(is_completed=True), session)
        assert toggle_1["xp_earned"] == 65
        assert toggle_1["total_xp"] == 65
        assert toggle_1["current_level"] == 1
        assert toggle_1["leveled_up"] is False
        assert len(toggle_1["new_badges"]) == 1 # "First Step" badge awarded!
        assert toggle_1["new_badges"][0]["id"] == "first_step"
        print(f"[PASS] 9a. Feature 2: Task 1 earned +65 XP, awarded badge '{toggle_1['new_badges'][0]['title']}'.")

        # Complete task 2 (45 mins = 65 XP, total becomes 130 XP >= 100 XP -> LEVEL UP to Level 2!)
        second_task = tasks_batch_2[1]
        toggle_2 = toggle_task_status(second_task.id, ToggleTaskRequest(is_completed=True), session)
        assert toggle_2["xp_earned"] == 65
        assert toggle_2["total_xp"] == 130
        assert toggle_2["current_level"] == 2
        assert toggle_2["leveled_up"] is True
        assert toggle_2["current_level_xp"] == 30 # 130 - 100 = 30 XP in level 2
        assert toggle_2["next_level_xp"] == 200 # Level 2 requires 200 XP
        print(f"[PASS] 9b. Feature 2: Level-Up Bug Fixed! Total XP: 130 -> Successfully advanced to Level 2 (leveled_up=True).")

        # Verify gamification profile endpoint reflects this immediately
        gamif_prof = get_gamification_profile(test_user_id, session)
        assert gamif_prof["current_level"] == 2
        assert gamif_prof["total_xp"] == 130
        assert "first_step" in gamif_prof["badge_ids"]
        print("[PASS] 9c. Feature 2: Gamification Profile state synchronized across endpoints.")

        # TEST 10: FEATURE 3 - Study Squads & Achievement Sharing
        # Create a squad
        created_squad_res = create_squad(
            CreateSquadRequest(
                name="Tanvi's High-Velocity Coders",
                description="Daily sprint study squad",
                focus_subject="Programming",
                creator_id=test_user_id,
                creator_name="Tanvi Deshmukh",
                is_private=False
            ),
            session
        )
        squad_id = created_squad_res["squad"].id
        squad_code = created_squad_res["squad"].code
        assert squad_id is not None
        assert squad_code.startswith("SQD-")
        print(f"[PASS] 10a. Feature 3: Created Study Squad '{created_squad_res['squad'].name}' with Code {squad_code}.")

        # Join squad using code
        join_res = join_squad(
            JoinSquadRequest(
                code=squad_code,
                student_id="test-scholar-peer-99",
                student_name="Aarav Sharma"
            ),
            session
        )
        assert join_res["squad_id"] == squad_id
        print(f"[PASS] 10b. Feature 3: Peer joined squad using invite code '{squad_code}'.")

        # Broadcast milestone message to feed
        post_res = post_to_squad_feed(
            squad_id,
            PostFeedItemRequest(
                student_id=test_user_id,
                student_name="Tanvi Deshmukh",
                activity_type="milestone",
                content="Just crushed 2 C++ memory layout sprints! Let's maintain the streak 🔥",
                badge_name="Sprint Finisher"
            ),
            session
        )
        item_id = post_res["item"].id
        assert item_id is not None

        # React to feed item with "fire" emoji
        react_res = react_to_feed_item(
            item_id,
            FeedReactionRequest(student_id="test-scholar-peer-99", reaction="fire"),
            session
        )
        assert react_res["reactions"]["fire"] == 1
        # Toggle reaction off
        react_res_2 = react_to_feed_item(
            item_id,
            FeedReactionRequest(student_id="test-scholar-peer-99", reaction="fire"),
            session
        )
        assert react_res_2["reactions"]["fire"] == 0
        print("[PASS] 10c. Feature 3: Squad feed broadcast and interactive reaction toggling verified.")

        # TEST 11: FEATURE 4 - Global Leaderboard & Standings
        # Fetch leaderboard sorted by XP
        lead_xp = get_global_leaderboard(metric="xp", timeframe="all", student_id=test_user_id, session=session)
        assert len(lead_xp["podium"]) == 3
        assert len(lead_xp["leaderboard"]) >= 3
        assert lead_xp["user_standing"] is not None
        assert lead_xp["user_standing"]["total_xp"] == 130
        assert lead_xp["user_standing"]["rank"] > 0
        assert lead_xp["user_standing"]["percentile"] > 0

        # Fetch leaderboard sorted by streak
        lead_streak = get_global_leaderboard(metric="streak", timeframe="weekly", student_id=test_user_id, session=session)
        assert len(lead_streak["leaderboard"]) >= 3
        print(f"[PASS] 11. Feature 4: Global Leaderboard ranked {lead_xp['total_scholars_count']} scholars worldwide (User Rank #{lead_xp['user_standing']['rank']}, Top {lead_xp['user_standing']['percentile']}%).")

        # Teardown test data cleanly
        for f in session.exec(select(SquadFeedItem).where(SquadFeedItem.squad_id == squad_id)).all():
            session.delete(f)
        for m in session.exec(select(SquadMember).where(SquadMember.squad_id == squad_id)).all():
            session.delete(m)
        squad_obj = session.get(StudySquad, squad_id)
        if squad_obj: session.delete(squad_obj)
        for u in session.exec(select(UserProfile).where(UserProfile.id == test_user_id)).all():
            session.delete(u)
        for t in session.exec(select(PlannerTask).where(PlannerTask.student_id == test_user_id)).all():
            session.delete(t)
        session.commit()

    print("\n=================================================================")
    print("ALL 11 ADVANCED FULL-STACK AUDIT CONTRACTS VERIFIED 100% OPERATIONAL")
    print("=================================================================")

if __name__ == "__main__":
    run_tests()
