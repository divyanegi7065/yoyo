import uuid
import json
import re
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlmodel import Session, select
from database import get_session
from models import UserProfile, PlannerTask, StudySquad, SquadMember, SquadFeedItem
from services.groq_service import generate_planner_roadmap
from services.gamification_service import (
    calculate_progression,
    evaluate_badges,
    get_xp_for_task,
    extract_subject,
    BADGE_CATALOGUE
)

router = APIRouter(prefix="/api", tags=["Planner & Gamification"])

class ProfileUpdateRequest(BaseModel):
    id: Optional[str] = None
    full_name: Optional[str] = "Student"
    email: Optional[str] = ""
    grade_stream: str = "Class 11 Science"
    focus_span_minutes: int = 45
    school_start_time: str = "08:00"
    school_end_time: str = "15:00"
    sleep_start_time: str = "23:00"
    peak_energy: str = "Late Night"
    daily_task_goal: Optional[int] = 4

class GenerateRoadmapRequest(BaseModel):
    student_id: str
    target_goal: str
    deadline_date: str
    daily_hours: float = 2.5

class ToggleTaskRequest(BaseModel):
    is_completed: Optional[bool] = None

@router.get("/onboarding/profile/{student_id}")
def get_user_profile(student_id: str, session: Session = Depends(get_session)):
    profile = session.exec(select(UserProfile).where(UserProfile.id == student_id)).first()
    if not profile:
        profile = UserProfile(id=student_id, full_name="Scholar")
        session.add(profile)
        session.commit()
        session.refresh(profile)
    return profile

@router.post("/onboarding/profile")
def save_or_update_profile(req: ProfileUpdateRequest, session: Session = Depends(get_session)):
    user_id = req.id if req.id and req.id.strip() else f"user-{uuid.uuid4().hex[:12]}"
    profile = session.exec(select(UserProfile).where(UserProfile.id == user_id)).first()
    
    if not profile:
        profile = UserProfile(id=user_id)

    profile.full_name = req.full_name or profile.full_name or "Scholar"
    profile.email = req.email or profile.email or ""
    profile.grade_stream = req.grade_stream
    profile.focus_span_minutes = req.focus_span_minutes
    profile.school_start_time = req.school_start_time
    profile.school_end_time = req.school_end_time
    profile.sleep_start_time = req.sleep_start_time
    profile.peak_energy = req.peak_energy
    if req.daily_task_goal:
        profile.daily_task_goal = req.daily_task_goal

    session.add(profile)
    session.commit()
    session.refresh(profile)
    return {
        "message": "Profile saved successfully",
        "user_id": profile.id,
        "profile": profile
    }

@router.get("/planner/tasks/{student_id}")
def get_student_tasks(student_id: str, session: Session = Depends(get_session)):
    tasks = session.exec(
        select(PlannerTask)
        .where(PlannerTask.student_id == student_id)
        .order_by(PlannerTask.scheduled_date.asc(), PlannerTask.id.asc())
    ).all()
    return tasks

@router.post("/planner/generate")
def generate_schedule(req: GenerateRoadmapRequest, session: Session = Depends(get_session)):
    if not req.target_goal or not req.target_goal.strip():
        raise HTTPException(status_code=400, detail="Target goal is required")

    profile = session.exec(select(UserProfile).where(UserProfile.id == req.student_id)).first()
    profile_dict = profile.model_dump() if profile else {
        "grade_stream": "General Academic",
        "focus_span_minutes": 45,
        "school_start_time": "08:00",
        "school_end_time": "15:00",
        "sleep_start_time": "23:00",
        "peak_energy": "Late Night"
    }

    # Deduplication: remove existing uncompleted tasks matching keywords
    goal_clean = req.target_goal.strip()
    goal_lower = goal_clean.lower()
    keywords = [w.lower() for w in re.split(r'[\s&,:-]+', goal_clean) if len(w) >= 3]

    existing_uncompleted = session.exec(
        select(PlannerTask).where(
            PlannerTask.student_id == req.student_id,
            PlannerTask.is_completed == False
        )
    ).all()

    deleted_duplicates_count = 0
    for t in existing_uncompleted:
        t_lower = t.topic_name.lower()
        if (
            goal_lower in t_lower or
            t_lower.startswith(goal_lower[:8]) or
            (len(keywords) > 0 and sum(1 for kw in keywords if kw in t_lower) >= max(1, len(keywords) // 2))
        ):
            session.delete(t)
            deleted_duplicates_count += 1

    if deleted_duplicates_count > 0:
        session.commit()

    raw_tasks = generate_planner_roadmap(
        target_goal=req.target_goal.strip(),
        deadline_date=req.deadline_date,
        daily_hours=req.daily_hours,
        user_profile=profile_dict
    )

    created_tasks = []
    detected_subj = extract_subject(goal_clean)

    for item in raw_tasks:
        scheduled_date = item.get("scheduled_date") or item.get("date") or datetime.utcnow().strftime("%Y-%m-%d")
        raw_topic = item.get("topic_name") or item.get("topic") or "Study Sprint"
        if not raw_topic.lower().startswith(goal_lower[:8]) and not goal_lower in raw_topic.lower():
            topic_name = f"{goal_clean}: {raw_topic}"
        else:
            topic_name = raw_topic

        duration = int(item.get("duration_minutes") or profile_dict.get("focus_span_minutes", 45))

        task = PlannerTask(
            student_id=req.student_id,
            topic_name=topic_name,
            scheduled_date=scheduled_date,
            duration_minutes=duration,
            is_completed=False,
            is_missed=False,
            subject=detected_subj
        )
        session.add(task)
        created_tasks.append(task)

    session.commit()
    return {
        "message": f"Successfully created {len(created_tasks)} tasks for '{req.target_goal}'" + (
            f" (replaced {deleted_duplicates_count} previous uncompleted tasks)." if deleted_duplicates_count > 0 else "."
        ),
        "tasks": [t.model_dump() for t in created_tasks]
    }

@router.post("/planner/reschedule-missed/{student_id}")
def reschedule_missed_tasks(student_id: str, session: Session = Depends(get_session)):
    today_str = datetime.utcnow().strftime("%Y-%m-%d")
    today_date = datetime.utcnow().date()

    missed_tasks = session.exec(
        select(PlannerTask).where(
            PlannerTask.student_id == student_id,
            PlannerTask.scheduled_date < today_str,
            PlannerTask.is_completed == False
        )
    ).all()

    if not missed_tasks:
        return {"message": "No missed backlog tasks found to reschedule.", "rescheduled_count": 0}

    rescheduled_count = len(missed_tasks)
    for idx, task in enumerate(missed_tasks):
        days_ahead = (idx % 4) + 1
        new_date = (today_date + timedelta(days=days_ahead)).strftime("%Y-%m-%d")
        task.scheduled_date = new_date
        task.is_missed = False
        session.add(task)

    session.commit()
    return {
        "message": f"Successfully rebalanced {rescheduled_count} missed tasks across upcoming study sessions.",
        "rescheduled_count": rescheduled_count
    }

# --- FEATURE 2: ROBUST LEVEL PROGRESSION HANDLER ---

@router.patch("/planner/tasks/{task_id}/toggle")
def toggle_task_status(task_id: int, req: Optional[ToggleTaskRequest] = None, session: Session = Depends(get_session)):
    """
    Toggles task status and immediately triggers the progression engine:
    1. Awards / retracts XP based on task duration.
    2. Recalculates level, remainder XP, next level XP threshold, and tier.
    3. Detects level advancement and tier transitions.
    4. Evaluates milestone badges and awards any newly qualified badges.
    5. Dispatches automatic celebrations to any enrolled Study Squads.
    """
    task = session.get(PlannerTask, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    old_status = task.is_completed
    new_status = req.is_completed if (req and req.is_completed is not None) else not old_status
    task.is_completed = new_status
    session.add(task)

    # 1. Fetch or create student profile
    profile = session.exec(select(UserProfile).where(UserProfile.id == task.student_id)).first()
    if not profile:
        profile = UserProfile(id=task.student_id, full_name="Scholar")
        session.add(profile)
        session.commit()
        session.refresh(profile)

    # 2. XP Delta Calculation
    xp_amount = get_xp_for_task(task.duration_minutes)
    xp_delta = xp_amount if new_status else -xp_amount

    old_xp = getattr(profile, "total_xp", 0) or 0
    old_prog = calculate_progression(old_xp)
    old_level = old_prog["current_level"]
    old_tier = old_prog["tier"]

    new_xp = max(0, old_xp + xp_delta)
    profile.total_xp = new_xp

    # 3. Dynamic Progressive Level & Tier Calculation
    new_prog = calculate_progression(new_xp)
    new_level = new_prog["current_level"]
    new_tier = new_prog["tier"]

    profile.current_level = new_level
    profile.tier = new_tier

    leveled_up = new_level > old_level
    tier_upgraded = new_tier != old_tier

    # 4. Compute streak & completed tasks count for badge assessment
    all_tasks = session.exec(select(PlannerTask).where(PlannerTask.student_id == task.student_id)).all()
    completed_count = sum(1 for t in all_tasks if t.is_completed)

    heatmap: Dict[str, int] = {}
    for t in all_tasks:
        if t.is_completed:
            heatmap[t.scheduled_date] = heatmap.get(t.scheduled_date, 0) + 1

    streak = 0
    curr_date = datetime.utcnow().date()
    if heatmap.get(curr_date.strftime("%Y-%m-%d"), 0) == 0:
        curr_date = curr_date - timedelta(days=1)
    while True:
        d_str = curr_date.strftime("%Y-%m-%d")
        if heatmap.get(d_str, 0) > 0:
            streak += 1
            curr_date -= timedelta(days=1)
        else:
            break

    # 5. Milestone Badges Evaluation
    try:
        existing_badge_ids = json.loads(profile.badges_json or "[]")
    except Exception:
        existing_badge_ids = []

    updated_badge_ids, newly_awarded_badges = evaluate_badges(
        total_tasks_completed=completed_count,
        streak_days=streak,
        total_xp=new_xp,
        current_level=new_level,
        existing_badge_ids=existing_badge_ids
    )
    profile.badges_json = json.dumps(updated_badge_ids)

    # 6. Automatic broadcast to enrolled Study Squad feeds
    if leveled_up:
        squad_memberships = session.exec(select(SquadMember).where(SquadMember.student_id == profile.id)).all()
        for sm in squad_memberships:
            # Update contributed XP
            sm.xp_contributed = max(0, sm.xp_contributed + xp_delta)
            session.add(sm)
            feed_item = SquadFeedItem(
                squad_id=sm.squad_id,
                student_id=profile.id,
                student_name=profile.full_name or "Scholar",
                activity_type="level_up",
                content=f"🎉 Leveled up to Level {new_level} ({new_tier})! Keep the momentum going!",
                badge_name=new_tier,
                reactions_json=json.dumps({"fire": 3, "clap": 4, "rocket": 5, "brain": 1, "heart": 3})
            )
            session.add(feed_item)

    for badge in newly_awarded_badges:
        squad_memberships = session.exec(select(SquadMember).where(SquadMember.student_id == profile.id)).all()
        for sm in squad_memberships:
            feed_item = SquadFeedItem(
                squad_id=sm.squad_id,
                student_id=profile.id,
                student_name=profile.full_name or "Scholar",
                activity_type="badge_earned",
                content=f"🏆 Unlocked badge: {badge['title']} - {badge['description']}",
                badge_name=badge['title'],
                reactions_json=json.dumps({"fire": 2, "clap": 3, "rocket": 4, "brain": 2, "heart": 2})
            )
            session.add(feed_item)

    session.add(profile)
    session.commit()
    session.refresh(task)
    session.refresh(profile)

    return {
        "message": "Task updated successfully",
        "task": task,
        "xp_earned": xp_delta if new_status else 0,
        "total_xp": profile.total_xp,
        "current_level": profile.current_level,
        "current_level_xp": new_prog["current_level_xp"],
        "next_level_xp": new_prog["next_level_xp"],
        "progress_percentage": new_prog["progress_percentage"],
        "tier": profile.tier,
        "leveled_up": leveled_up,
        "tier_upgraded": tier_upgraded,
        "new_badges": newly_awarded_badges,
        "badges": updated_badge_ids
    }

# --- FEATURE 1: SUBJECT-WISE PROGRESSION GRAPH ENDPOINT ---

@router.get("/planner/subjects/{student_id}")
def get_subject_progress(student_id: str, session: Session = Depends(get_session)):
    """
    Computes real-time subject-wise task completion & remaining count against daily goals.
    """
    all_tasks = session.exec(select(PlannerTask).where(PlannerTask.student_id == student_id)).all()
    profile = session.exec(select(UserProfile).where(UserProfile.id == student_id)).first()
    daily_goal = getattr(profile, "daily_task_goal", 4) if profile else 4

    today_str = datetime.utcnow().strftime("%Y-%m-%d")
    today_tasks = [t for t in all_tasks if t.scheduled_date == today_str]

    subject_map: Dict[str, Dict[str, Any]] = {}

    # 1. Group today's scheduled tasks
    for t in today_tasks:
        subj = extract_subject(t.topic_name, getattr(t, "subject", None))
        if subj not in subject_map:
            subject_map[subj] = {
                "subject": subj,
                "today_total": 0,
                "today_completed": 0,
                "today_remaining": 0,
                "all_time_completed": 0,
                "all_time_total": 0,
                "daily_goal": max(1, daily_goal // 2)
            }
        subject_map[subj]["today_total"] += 1
        if t.is_completed:
            subject_map[subj]["today_completed"] += 1
        else:
            subject_map[subj]["today_remaining"] += 1

    # 2. Add all-time statistics
    for t in all_tasks:
        subj = extract_subject(t.topic_name, getattr(t, "subject", None))
        if subj in subject_map:
            subject_map[subj]["all_time_total"] += 1
            if t.is_completed:
                subject_map[subj]["all_time_completed"] += 1
        else:
            # Register historical subject even if none scheduled today
            subject_map[subj] = {
                "subject": subj,
                "today_total": 0,
                "today_completed": 0,
                "today_remaining": 0,
                "all_time_completed": 1 if t.is_completed else 0,
                "all_time_total": 1,
                "daily_goal": max(1, daily_goal // 2)
            }

    # Fallback to default curriculum subjects if user has zero tasks yet
    if not subject_map:
        for subj in ["Physics", "Mathematics", "Programming"]:
            subject_map[subj] = {
                "subject": subj,
                "today_total": 0,
                "today_completed": 0,
                "today_remaining": 0,
                "all_time_completed": 0,
                "all_time_total": 0,
                "daily_goal": 2
            }

    subjects_list = []
    for s_name, data in subject_map.items():
        # Predefined daily goal: either user set goal or scheduled count
        target = max(data["daily_goal"], data["today_total"])
        remaining_against_goal = max(0, target - data["today_completed"])
        pct = round((data["today_completed"] / target) * 100) if target > 0 else 0
        pct = min(100, pct)

        subjects_list.append({
            "subject": s_name,
            "completed_today": data["today_completed"],
            "remaining_today": data["today_remaining"],
            "daily_goal": target,
            "remaining_against_goal": remaining_against_goal,
            "completion_percentage": pct,
            "all_time_completed": data["all_time_completed"],
            "all_time_total": data["all_time_total"]
        })

    # Sort so subjects with active tasks today appear first
    subjects_list.sort(key=lambda x: (x["completed_today"] + x["remaining_today"], x["all_time_total"]), reverse=True)

    total_today_completed = sum(s["completed_today"] for s in subjects_list)
    total_today_remaining = sum(s["remaining_today"] for s in subjects_list)
    total_daily_goal = sum(s["daily_goal"] for s in subjects_list)

    return {
        "student_id": student_id,
        "date": today_str,
        "subjects": subjects_list,
        "summary": {
            "total_completed": total_today_completed,
            "total_remaining": total_today_remaining,
            "total_goal": total_daily_goal,
            "overall_goal_percentage": round((total_today_completed / total_daily_goal * 100)) if total_daily_goal > 0 else 0
        }
    }

# --- GAMIFICATION PROFILE STATUS ENDPOINT ---

@router.get("/gamification/profile/{student_id}")
def get_gamification_profile(student_id: str, session: Session = Depends(get_session)):
    profile = session.exec(select(UserProfile).where(UserProfile.id == student_id)).first()
    if not profile:
        profile = UserProfile(id=student_id, full_name="Scholar")
        session.add(profile)
        session.commit()
        session.refresh(profile)

    total_xp = getattr(profile, "total_xp", 0) or 0
    prog = calculate_progression(total_xp)

    try:
        badge_ids = json.loads(profile.badges_json or "[]")
    except Exception:
        badge_ids = []

    badge_lookup = {b["id"]: b for b in BADGE_CATALOGUE}
    awarded_badge_objects = [badge_lookup[b_id] for b_id in badge_ids if b_id in badge_lookup]

    return {
        "student_id": student_id,
        "full_name": profile.full_name,
        "total_xp": prog["total_xp"],
        "current_level": prog["current_level"],
        "current_level_xp": prog["current_level_xp"],
        "next_level_xp": prog["next_level_xp"],
        "progress_percentage": prog["progress_percentage"],
        "tier": prog["tier"],
        "badge_ids": badge_ids,
        "badges": awarded_badge_objects,
        "all_badges": BADGE_CATALOGUE
    }

@router.get("/planner/analytics/{student_id}")
def get_planner_analytics(student_id: str, session: Session = Depends(get_session)):
    all_tasks = session.exec(select(PlannerTask).where(PlannerTask.student_id == student_id)).all()
    profile = session.exec(select(UserProfile).where(UserProfile.id == student_id)).first()
    today_str = datetime.utcnow().strftime("%Y-%m-%d")

    total = len(all_tasks)
    completed = sum(1 for t in all_tasks if t.is_completed)
    backlogs = sum(1 for t in all_tasks if t.scheduled_date < today_str and not t.is_completed)

    heatmap: Dict[str, int] = {}
    for t in all_tasks:
        if t.is_completed:
            heatmap[t.scheduled_date] = heatmap.get(t.scheduled_date, 0) + 1

    # Real streak calculation
    streak = 0
    curr_date = datetime.utcnow().date()
    if heatmap.get(curr_date.strftime("%Y-%m-%d"), 0) == 0:
        curr_date = curr_date - timedelta(days=1)

    while True:
        d_str = curr_date.strftime("%Y-%m-%d")
        if heatmap.get(d_str, 0) > 0:
            streak += 1
            curr_date -= timedelta(days=1)
        else:
            break

    total_xp = getattr(profile, "total_xp", 0) if profile else 0
    prog = calculate_progression(total_xp)

    try:
        badge_ids = json.loads(profile.badges_json or "[]") if profile else []
    except Exception:
        badge_ids = []

    return {
        "student_id": student_id,
        "total_tasks": total,
        "completed_tasks": completed,
        "completion_rate": round((completed / total * 100), 1) if total > 0 else 0.0,
        "streak_days": streak,
        "backlog_count": backlogs,
        "heatmap": heatmap,
        "total_xp": prog["total_xp"],
        "current_level": prog["current_level"],
        "current_level_xp": prog["current_level_xp"],
        "next_level_xp": prog["next_level_xp"],
        "progress_percentage": prog["progress_percentage"],
        "tier": prog["tier"],
        "badges_count": len(badge_ids)
    }
