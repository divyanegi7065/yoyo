import json
import random
import uuid
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlmodel import Session, select
from database import get_session
from models import (
    UserProfile,
    PlannerTask,
    StudySquad,
    SquadMember,
    SquadFeedItem
)
from services.gamification_service import calculate_progression, BADGE_CATALOGUE

router = APIRouter(prefix="/api/social", tags=["Study Squads & Global Leaderboard"])

# --- Request Payloads ---
class CreateSquadRequest(BaseModel):
    name: str
    description: Optional[str] = ""
    focus_subject: Optional[str] = "General Academic"
    creator_id: str
    creator_name: Optional[str] = "Scholar"
    is_private: bool = False

class JoinSquadRequest(BaseModel):
    code: str
    student_id: str
    student_name: Optional[str] = "Scholar"

class PostFeedItemRequest(BaseModel):
    student_id: str
    student_name: Optional[str] = "Scholar"
    activity_type: Optional[str] = "message" # milestone, level_up, streak, task_completed, message
    content: str
    badge_name: Optional[str] = None

class FeedReactionRequest(BaseModel):
    student_id: str
    reaction: str # fire, clap, rocket, brain, heart

# --- Helper to generate unique squad codes ---
def generate_squad_code(prefix: str = "SQD") -> str:
    rnd = random.randint(1000, 9999)
    return f"{prefix}-{rnd}"

# --- STUDY SQUADS ENDPOINTS ---

@router.get("/squads")
def list_squads(student_id: Optional[str] = None, session: Session = Depends(get_session)):
    """
    Returns public study squads and squads the student is a member of.
    """
    all_squads = session.exec(select(StudySquad)).all()
    
    # If no squads exist, seed 3 diverse active public study squads
    if not all_squads:
        seed_squads = [
            {
                "name": "NEET Titans 2026",
                "code": "NEET-26",
                "description": "Daily 6-hour sprint squad for NEET Biology & Organic Chemistry mastery.",
                "focus_subject": "Biology",
                "creator_id": "seed-user-1",
                "creator_name": "Dr. Aisha",
                "is_private": False,
            },
            {
                "name": "Silicon Coders & Algorithmic Prep",
                "code": "DEV-2026",
                "description": "Full-stack web devs, C++ pointer specialists, and leetcode problem solvers.",
                "focus_subject": "Programming",
                "creator_id": "seed-user-2",
                "creator_name": "Devansh M.",
                "is_private": False,
            },
            {
                "name": "IIT-JEE Calculus & Physics Syndicate",
                "code": "JEE-AIR1",
                "description": "Deep problem solving for Mechanics, Thermodynamics, and Differential Calculus.",
                "focus_subject": "Physics",
                "creator_id": "seed-user-3",
                "creator_name": "Rohan V.",
                "is_private": False,
            }
        ]
        created = []
        for s in seed_squads:
            squad = StudySquad(**s)
            session.add(squad)
            session.commit()
            session.refresh(squad)
            # Add creator member
            session.add(SquadMember(
                squad_id=squad.id,
                student_id=s["creator_id"],
                student_name=s["creator_name"],
                role="admin",
                xp_contributed=random.randint(600, 1800)
            ))
            # Seed initial celebratory feed items
            session.add(SquadFeedItem(
                squad_id=squad.id,
                student_id=s["creator_id"],
                student_name=s["creator_name"],
                activity_type="milestone",
                content=f"Welcome to {s['name']}! Let's conquer our daily goals together 🚀",
                badge_name="Squad Founder",
                reactions_json=json.dumps({"fire": 5, "clap": 8, "rocket": 12, "brain": 3, "heart": 7})
            ))
            session.commit()
            created.append(squad)
        all_squads = created

    # Enrich squad data with member counts and user membership
    user_squad_ids = set()
    if student_id:
        user_memberships = session.exec(select(SquadMember).where(SquadMember.student_id == student_id)).all()
        user_squad_ids = {m.squad_id for m in user_memberships}

    result = []
    for sq in all_squads:
        members = session.exec(select(SquadMember).where(SquadMember.squad_id == sq.id)).all()
        result.append({
            "id": sq.id,
            "name": sq.name,
            "code": sq.code,
            "description": sq.description,
            "focus_subject": sq.focus_subject,
            "creator_id": sq.creator_id,
            "creator_name": sq.creator_name,
            "is_private": sq.is_private,
            "created_at": sq.created_at,
            "member_count": len(members),
            "is_member": sq.id in user_squad_ids,
            "top_members": [
                {"name": m.student_name, "xp": m.xp_contributed, "role": m.role}
                for m in sorted(members, key=lambda x: x.xp_contributed, reverse=True)[:3]
            ]
        })

    return {"squads": result}

@router.post("/squads")
def create_squad(req: CreateSquadRequest, session: Session = Depends(get_session)):
    clean_name = req.name.strip()
    if not clean_name:
        raise HTTPException(status_code=400, detail="Squad name is required")

    code = generate_squad_code()
    # Ensure code uniqueness
    while session.exec(select(StudySquad).where(StudySquad.code == code)).first():
        code = generate_squad_code()

    squad = StudySquad(
        name=clean_name,
        code=code,
        description=req.description or "Collaborative study squad",
        focus_subject=req.focus_subject or "General Academic",
        creator_id=req.creator_id,
        creator_name=req.creator_name or "Scholar",
        is_private=req.is_private
    )
    session.add(squad)
    session.commit()
    session.refresh(squad)

    # Add creator as admin member
    member = SquadMember(
        squad_id=squad.id,
        student_id=req.creator_id,
        student_name=req.creator_name or "Scholar",
        role="admin",
        xp_contributed=100
    )
    session.add(member)

    # Add welcome broadcast to squad feed
    feed_item = SquadFeedItem(
        squad_id=squad.id,
        student_id=req.creator_id,
        student_name=req.creator_name or "Scholar",
        activity_type="milestone",
        content=f"Created squad '{squad.name}'! Code to invite peers: {squad.code}",
        badge_name="Squad Founder",
        reactions_json=json.dumps({"fire": 1, "clap": 2, "rocket": 3, "brain": 0, "heart": 1})
    )
    session.add(feed_item)
    session.commit()

    return {
        "message": f"Squad '{squad.name}' created successfully!",
        "squad": squad
    }

@router.post("/squads/join")
def join_squad(req: JoinSquadRequest, session: Session = Depends(get_session)):
    code_clean = req.code.strip().upper()
    squad = session.exec(select(StudySquad).where(StudySquad.code == code_clean)).first()
    if not squad:
        raise HTTPException(status_code=404, detail=f"No squad found with code '{code_clean}'")

    existing_member = session.exec(
        select(SquadMember).where(
            SquadMember.squad_id == squad.id,
            SquadMember.student_id == req.student_id
        )
    ).first()

    if existing_member:
        return {
            "message": f"You are already a member of '{squad.name}'",
            "squad_id": squad.id,
            "squad": squad
        }

    # Fetch user's current XP for contribution
    profile = session.exec(select(UserProfile).where(UserProfile.id == req.student_id)).first()
    user_xp = getattr(profile, "total_xp", 0) if profile else 0

    new_member = SquadMember(
        squad_id=squad.id,
        student_id=req.student_id,
        student_name=req.student_name or "Scholar",
        role="member",
        xp_contributed=user_xp
    )
    session.add(new_member)

    # Post join announcement to feed
    feed_item = SquadFeedItem(
        squad_id=squad.id,
        student_id=req.student_id,
        student_name=req.student_name or "Scholar",
        activity_type="milestone",
        content=f"👋 Joined the squad! Ready to crush today's study sprints.",
        reactions_json=json.dumps({"fire": 2, "clap": 3, "rocket": 1, "brain": 0, "heart": 2})
    )
    session.add(feed_item)
    session.commit()

    return {
        "message": f"Successfully joined '{squad.name}'!",
        "squad_id": squad.id,
        "squad": squad
    }

@router.get("/squads/{squad_id}/feed")
def get_squad_feed(squad_id: int, session: Session = Depends(get_session)):
    squad = session.get(StudySquad, squad_id)
    if not squad:
        raise HTTPException(status_code=404, detail="Squad not found")

    feed_items = session.exec(
        select(SquadFeedItem)
        .where(SquadFeedItem.squad_id == squad_id)
        .order_by(SquadFeedItem.id.desc())
    ).all()

    # Get members roster
    members = session.exec(
        select(SquadMember)
        .where(SquadMember.squad_id == squad_id)
        .order_by(SquadMember.xp_contributed.desc())
    ).all()

    feed_list = []
    for item in feed_items:
        try:
            reactions = json.loads(item.reactions_json or "{}")
        except Exception:
            reactions = {"fire": 0, "clap": 0, "rocket": 0, "brain": 0, "heart": 0}

        try:
            reacted_users = json.loads(item.reacted_users_json or "{}")
        except Exception:
            reacted_users = {}

        feed_list.append({
            "id": item.id,
            "squad_id": item.squad_id,
            "student_id": item.student_id,
            "student_name": item.student_name,
            "activity_type": item.activity_type,
            "content": item.content,
            "badge_name": item.badge_name,
            "created_at": item.created_at,
            "reactions": reactions,
            "reacted_users": reacted_users
        })

    return {
        "squad": {
            "id": squad.id,
            "name": squad.name,
            "code": squad.code,
            "description": squad.description,
            "focus_subject": squad.focus_subject,
            "creator_id": squad.creator_id,
            "creator_name": squad.creator_name,
            "created_at": squad.created_at,
            "members": [
                {
                    "student_id": m.student_id,
                    "student_name": m.student_name,
                    "role": m.role,
                    "xp_contributed": m.xp_contributed,
                    "joined_at": m.joined_at
                }
                for m in members
            ]
        },
        "feed": feed_list
    }

@router.post("/squads/{squad_id}/feed")
def post_to_squad_feed(squad_id: int, req: PostFeedItemRequest, session: Session = Depends(get_session)):
    squad = session.get(StudySquad, squad_id)
    if not squad:
        raise HTTPException(status_code=404, detail="Squad not found")

    clean_content = req.content.strip()
    if not clean_content:
        raise HTTPException(status_code=400, detail="Content cannot be empty")

    item = SquadFeedItem(
        squad_id=squad_id,
        student_id=req.student_id,
        student_name=req.student_name or "Scholar",
        activity_type=req.activity_type or "message",
        content=clean_content,
        badge_name=req.badge_name,
        reactions_json=json.dumps({"fire": 0, "clap": 0, "rocket": 0, "brain": 0, "heart": 0}),
        reacted_users_json=json.dumps({})
    )
    session.add(item)
    session.commit()
    session.refresh(item)

    return {
        "message": "Broadcast posted successfully",
        "item": item
    }

@router.post("/feed/{item_id}/react")
def react_to_feed_item(item_id: int, req: FeedReactionRequest, session: Session = Depends(get_session)):
    item = session.get(SquadFeedItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Feed item not found")

    valid_reactions = ["fire", "clap", "rocket", "brain", "heart"]
    reaction = req.reaction.lower().strip()
    if reaction not in valid_reactions:
        raise HTTPException(status_code=400, detail=f"Invalid reaction. Must be one of {valid_reactions}")

    try:
        reactions_data = json.loads(item.reactions_json or "{}")
    except Exception:
        reactions_data = {"fire": 0, "clap": 0, "rocket": 0, "brain": 0, "heart": 0}

    try:
        reacted_users = json.loads(item.reacted_users_json or "{}")
    except Exception:
        reacted_users = {}

    user_list = reacted_users.get(reaction, [])

    if req.student_id in user_list:
        # Toggle off (unreact)
        user_list.remove(req.student_id)
        reactions_data[reaction] = max(0, reactions_data.get(reaction, 1) - 1)
    else:
        # Toggle on (react)
        user_list.append(req.student_id)
        reactions_data[reaction] = reactions_data.get(reaction, 0) + 1

    reacted_users[reaction] = user_list
    item.reactions_json = json.dumps(reactions_data)
    item.reacted_users_json = json.dumps(reacted_users)

    session.add(item)
    session.commit()
    session.refresh(item)

    return {
        "item_id": item.id,
        "reactions": reactions_data,
        "reacted_users": reacted_users
    }

# --- GLOBAL LEADERBOARD & STANDINGS ENDPOINTS ---

@router.get("/leaderboard/global")
def get_global_leaderboard(
    metric: str = Query("xp", pattern="^(xp|tasks|streak)$"),
    timeframe: str = Query("all", pattern="^(all|weekly|daily)$"),
    student_id: Optional[str] = None,
    session: Session = Depends(get_session)
):
    """
    Returns global leaderboard rankings based on metric (XP, tasks, streaks),
    highlighting the requesting student's rank and percentile standing.
    """
    # 1. Gather all actual users in database
    users = session.exec(select(UserProfile)).all()
    all_tasks = session.exec(select(PlannerTask)).all()

    # Pre-aggregate tasks by student
    user_task_counts: Dict[str, int] = {}
    user_streaks: Dict[str, int] = {}
    today_str = datetime.utcnow().strftime("%Y-%m-%d")

    for u in users:
        u_tasks = [t for t in all_tasks if t.student_id == u.id]
        completed = sum(1 for t in u_tasks if t.is_completed)
        user_task_counts[u.id] = completed

        # Streak calc
        heatmap: Dict[str, int] = {}
        for t in u_tasks:
            if t.is_completed:
                heatmap[t.scheduled_date] = heatmap.get(t.scheduled_date, 0) + 1
        streak = 0
        curr_date = datetime.utcnow().date()
        if heatmap.get(curr_date.strftime("%Y-%m-%d"), 0) == 0:
            curr_date = curr_date - timedelta(days=1)
        while True:
            d_str = curr_date.strftime("%Y-%m-%d")
            if heatmap.get(d_str, 0) > 0:
                streak += 1
                curr_date -= timedelta(days=1)
            else:
                break
        user_streaks[u.id] = streak

    # Seed realistic top global cohort for vibrant leaderboard
    global_scholars = [
        {"name": "Ananya Sharma", "grade": "Class 12 Science (PCM)", "xp": 3840, "tasks": 48, "streak": 24, "avatar": "👩‍🎓", "country": "IN"},
        {"name": "Kevin Zhang", "grade": "UG 2nd Year CS", "xp": 3420, "tasks": 42, "streak": 19, "avatar": "👨‍💻", "country": "US"},
        {"name": "Fatima Al-Mansoor", "grade": "Medical Entrance Prep", "xp": 3150, "tasks": 39, "streak": 16, "avatar": "🩺", "country": "AE"},
        {"name": "Siddharth Rao", "grade": "Class 11 Science", "xp": 2890, "tasks": 35, "streak": 14, "avatar": "🚀", "country": "IN"},
        {"name": "Elena Rostova", "grade": "Mathematics Honours", "xp": 2650, "tasks": 32, "streak": 12, "avatar": "📐", "country": "DE"},
        {"name": "Marcus Vance", "grade": "Commerce & Finance", "xp": 2340, "tasks": 29, "streak": 11, "avatar": "📈", "country": "UK"},
        {"name": "Diya Sengupta", "grade": "Class 10 ICSE", "xp": 2100, "tasks": 26, "streak": 9, "avatar": "🔬", "country": "IN"},
        {"name": "Lucas Silva", "grade": "Computer Engineering", "xp": 1820, "tasks": 23, "streak": 8, "avatar": "⚡", "country": "BR"},
        {"name": "Rohan Mehra", "grade": "Class 11 Science", "xp": 1560, "tasks": 20, "streak": 7, "avatar": "🔥", "country": "IN"},
        {"name": "Zoe Chen", "grade": "Biotechnology UG", "xp": 1390, "tasks": 18, "streak": 6, "avatar": "🧬", "country": "CA"}
    ]

    all_entries = []

    # Add real users
    for u in users:
        total_xp = getattr(u, "total_xp", 0) or 0
        tasks_done = user_task_counts.get(u.id, 0)
        streak_val = user_streaks.get(u.id, 0)
        prog = calculate_progression(total_xp)

        all_entries.append({
            "student_id": u.id,
            "student_name": u.full_name or "Scholar",
            "grade_stream": u.grade_stream or "General Academic",
            "total_xp": total_xp,
            "tasks_completed": tasks_done,
            "streak_days": streak_val,
            "level": prog["current_level"],
            "tier": prog["tier"],
            "avatar": "🎓",
            "is_current_user": (u.id == student_id) if student_id else False
        })

    # Add global scholars
    for idx, gs in enumerate(global_scholars):
        prog = calculate_progression(gs["xp"])
        all_entries.append({
            "student_id": f"global-scholar-{idx + 1}",
            "student_name": gs["name"],
            "grade_stream": gs["grade"],
            "total_xp": gs["xp"],
            "tasks_completed": gs["tasks"],
            "streak_days": gs["streak"],
            "level": prog["current_level"],
            "tier": prog["tier"],
            "avatar": gs["avatar"],
            "is_current_user": False
        })

    # Sort based on selected metric
    if metric == "tasks":
        all_entries.sort(key=lambda x: (x["tasks_completed"], x["total_xp"]), reverse=True)
    elif metric == "streak":
        all_entries.sort(key=lambda x: (x["streak_days"], x["total_xp"]), reverse=True)
    else: # xp
        all_entries.sort(key=lambda x: (x["total_xp"], x["tasks_completed"]), reverse=True)

    # Assign rank numbers
    total_participants = len(all_entries)
    user_standing = None

    for rank, entry in enumerate(all_entries, start=1):
        entry["rank"] = rank
        if entry["is_current_user"]:
            percentile = round(((total_participants - rank + 1) / total_participants) * 100, 1)
            next_scholar = all_entries[rank - 2] if rank > 1 else None
            user_standing = {
                "rank": rank,
                "total_participants": total_participants,
                "percentile": percentile,
                "tier": entry["tier"],
                "total_xp": entry["total_xp"],
                "tasks_completed": entry["tasks_completed"],
                "streak_days": entry["streak_days"],
                "xp_to_next_rank": (next_scholar["total_xp"] - entry["total_xp"] + 10) if next_scholar else 0,
                "next_scholar_name": next_scholar["student_name"] if next_scholar else None
            }

    # Top 3 Podium
    podium = all_entries[:3]

    return {
        "metric": metric,
        "timeframe": timeframe,
        "total_scholars_count": total_participants,
        "user_standing": user_standing,
        "podium": podium,
        "leaderboard": all_entries[:50]
    }
