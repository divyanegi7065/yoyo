import json
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime

# --- ALL BADGES CATALOGUE ---
BADGE_CATALOGUE = [
    {
        "id": "first_step",
        "title": "First Step",
        "description": "Completed your very first focus study sprint!",
        "icon": "🚀",
        "category": "tasks"
    },
    {
        "id": "sprint_master",
        "title": "Sprint Finisher",
        "description": "Crushed 5 study tasks with relentless focus!",
        "icon": "⚡",
        "category": "tasks"
    },
    {
        "id": "task_crusher",
        "title": "Task Crusher",
        "description": "Completed 10 study sprints like a machine!",
        "icon": "🎯",
        "category": "tasks"
    },
    {
        "id": "century_club",
        "title": "Century Club",
        "description": "Amassed over 500 XP across study sprints!",
        "icon": "💯",
        "category": "xp"
    },
    {
        "id": "streak_flame",
        "title": "Streak Flame",
        "description": "Ignited a 3-day consecutive study streak!",
        "icon": "🔥",
        "category": "streak"
    },
    {
        "id": "streak_legend",
        "title": "Streak Legend",
        "description": "Maintained an unstoppable 7-day study streak!",
        "icon": "🏆",
        "category": "streak"
    },
    {
        "id": "silver_ascendant",
        "title": "Silver Scholar",
        "description": "Advanced to Silver Scholar Tier (Level 4+)",
        "icon": "🥈",
        "category": "tier"
    },
    {
        "id": "gold_champion",
        "title": "Gold Master",
        "description": "Advanced to Gold Master Tier (Level 8+)",
        "icon": "🥇",
        "category": "tier"
    },
    {
        "id": "diamond_luminary",
        "title": "Diamond Prodigy",
        "description": "Reached the prestigious Diamond Tier (Level 20+)",
        "icon": "💎",
        "category": "tier"
    }
]

def get_tier(level: int) -> str:
    """Calculates player tier based on level."""
    if level >= 30:
        return "Mythic Luminary"
    elif level >= 20:
        return "Diamond Prodigy"
    elif level >= 13:
        return "Platinum Grandmaster"
    elif level >= 8:
        return "Gold Master"
    elif level >= 4:
        return "Silver Scholar"
    return "Bronze Scholar"

def get_xp_for_task(duration_minutes: int) -> int:
    """
    Base 50 XP + duration bonus (5 XP per 15 minutes).
    e.g. 45 min task = 50 + 15 = 65 XP.
    """
    duration_bonus = max(0, (duration_minutes // 15) * 5)
    return 50 + duration_bonus

def calculate_progression(total_xp: int) -> Dict[str, Any]:
    """
    Calculates level, current level XP remainder, next level XP needed,
    progress percentage, and tier.
    Uses dynamic progressive scaling: Level L requires 100 * L XP to reach L+1.
    """
    total_xp = max(0, int(total_xp))
    level = 1
    xp_remainder = total_xp

    while True:
        needed_for_next = 100 * level
        if xp_remainder >= needed_for_next:
            xp_remainder -= needed_for_next
            level += 1
        else:
            break

    next_level_required = 100 * level
    pct = round((xp_remainder / next_level_required) * 100) if next_level_required > 0 else 0
    pct = min(100, max(0, pct))
    tier = get_tier(level)

    return {
        "total_xp": total_xp,
        "current_level": level,
        "current_level_xp": xp_remainder,
        "next_level_xp": next_level_required,
        "progress_percentage": pct,
        "tier": tier
    }

def evaluate_badges(
    total_tasks_completed: int,
    streak_days: int,
    total_xp: int,
    current_level: int,
    existing_badge_ids: List[str]
) -> Tuple[List[str], List[Dict[str, Any]]]:
    """
    Evaluates milestone badge eligibility and returns (updated_badge_ids, newly_awarded_badges).
    """
    existing_set = set(existing_badge_ids)
    newly_awarded = []

    criteria_map = {
        "first_step": total_tasks_completed >= 1,
        "sprint_master": total_tasks_completed >= 5,
        "task_crusher": total_tasks_completed >= 10,
        "century_club": total_xp >= 500,
        "streak_flame": streak_days >= 3,
        "streak_legend": streak_days >= 7,
        "silver_ascendant": current_level >= 4,
        "gold_champion": current_level >= 8,
        "diamond_luminary": current_level >= 20,
    }

    badge_dict = {b["id"]: b for b in BADGE_CATALOGUE}

    for badge_id, met in criteria_map.items():
        if met and badge_id not in existing_set:
            existing_set.add(badge_id)
            badge_info = badge_dict.get(badge_id)
            if badge_info:
                newly_awarded.append({
                    **badge_info,
                    "awarded_at": datetime.utcnow().isoformat()
                })

    return list(existing_set), newly_awarded

def extract_subject(topic_name: str, explicit_subject: Optional[str] = None) -> str:
    """
    Extracts or normalizes subject classification from task topic name or explicit field.
    e.g. "Physics: Thermodynamics" -> "Physics"
         "C++ Data Types: Structs" -> "Programming"
         "Math - Calculus" -> "Mathematics"
    """
    if explicit_subject and explicit_subject.strip():
        return explicit_subject.strip().title()

    raw = topic_name.strip()
    # Check delimiters
    for delim in [":", "-", "—", "|", "•"]:
        if delim in raw:
            candidate = raw.split(delim)[0].strip()
            if len(candidate) >= 3:
                raw = candidate
                break

    lower = raw.lower()
    if any(k in lower for k in ["physics", "kinematics", "thermodynamics", "optics", "quantum", "gravity", "wave"]):
        return "Physics"
    elif any(k in lower for k in ["math", "calculus", "algebra", "geometry", "trigonometry", "matrix", "integration", "derivative"]):
        return "Mathematics"
    elif any(k in lower for k in ["c++", "python", "programming", "javascript", "code", "react", "html", "css", "data structure", "algorithm", "sql", "dev"]):
        return "Programming"
    elif any(k in lower for k in ["biology", "genetics", "dna", "cell", "zoology", "botany", "anatomy", "neet"]):
        return "Biology"
    elif any(k in lower for k in ["chemistry", "organic", "inorganic", "periodic", "molarity", "atom"]):
        return "Chemistry"
    elif any(k in lower for k in ["account", "ledger", "journal", "balance sheet", "finance", "economics", "commerce"]):
        return "Commerce"
    elif any(k in lower for k in ["history", "geography", "literature", "english", "psychology", "arts"]):
        return "Humanities"

    # Fallback to cleaned title (first 2-3 words)
    words = raw.split()
    if len(words) <= 2:
        return raw.title()
    return " ".join(words[:2]).title()

