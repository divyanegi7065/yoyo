import os
import sqlite3
from pathlib import Path
from sqlmodel import create_engine, SQLModel, Session

BASE_DIR = Path(__file__).resolve().parent
DB_FILE = BASE_DIR / "app.db"
DATABASE_URL = f"sqlite:///{DB_FILE}"

connect_args = {"check_same_thread": False}
engine = create_engine(DATABASE_URL, echo=False, connect_args=connect_args)

def migrate_db():
    """Ensure newly added columns exist in existing SQLite tables."""
    if not DB_FILE.exists():
        return

    conn = sqlite3.connect(str(DB_FILE))
    cursor = conn.cursor()

    try:
        # Check user_profile columns
        cursor.execute("PRAGMA table_info(user_profile)")
        user_cols = [row[1] for row in cursor.fetchall()]

        if "total_xp" not in user_cols:
            cursor.execute("ALTER TABLE user_profile ADD COLUMN total_xp INTEGER DEFAULT 0")
        if "current_level" not in user_cols:
            cursor.execute("ALTER TABLE user_profile ADD COLUMN current_level INTEGER DEFAULT 1")
        if "tier" not in user_cols:
            cursor.execute("ALTER TABLE user_profile ADD COLUMN tier TEXT DEFAULT 'Bronze Scholar'")
        if "badges_json" not in user_cols:
            cursor.execute("ALTER TABLE user_profile ADD COLUMN badges_json TEXT DEFAULT '[]'")
        if "daily_task_goal" not in user_cols:
            cursor.execute("ALTER TABLE user_profile ADD COLUMN daily_task_goal INTEGER DEFAULT 4")

        # Check planner_task columns
        cursor.execute("PRAGMA table_info(planner_task)")
        task_cols = [row[1] for row in cursor.fetchall()]
        if "subject" not in task_cols:
            cursor.execute("ALTER TABLE planner_task ADD COLUMN subject TEXT DEFAULT NULL")

        conn.commit()
    except Exception as e:
        print("Migration note:", e)
    finally:
        conn.close()

def init_db():
    import models  # Ensure all models are registered on SQLModel.metadata
    migrate_db()
    SQLModel.metadata.create_all(engine)
    migrate_db()

def get_session():
    with Session(engine) as session:
        yield session
